// Alapértékek meghatározása

let dobasok = [];
let dobasGombDB = 0;
let kockakSzama = 3;
let dobasokAtlaga = 0;
let maxIndex = 0;
let kockaEredmenyDB = TombGeneralo(6);
let dobas666DB = 0;
let dobasAAADB = 0;
let dobasABCDB = 0;
let dobasErtekSzamlalo = [];
let dobasEVENDB = 0;
let dobasODDDB = 0;
let dobasSTREAKDB = 0;


// Hivatkozás értékek

let dobasGomb = document.querySelector("#kockaDobas");
let dobasGomb100 = document.querySelector("#kockaDobas100");
let egyszerreDobasDB = document.querySelector("#egyszerreDobasDB");
let egyszerreDobasSUM = document.querySelector("#egyszerreDobasSUM");
let dobasSUMAVG = document.querySelector("#dobasSUMAVG");
let dobasSUMTOP = document.querySelector("#dobasSUMTOP");
let dobas666 = document.querySelector("#dobas666");
let dobasAAA = document.querySelector("#dobasAAA");
let dobasABC = document.querySelector("#dobasABC");
let dobasMOST = document.querySelector("#dobasMOST");
let dobasRARE = document.querySelector("#dobasRARE");
let dobasEVEN = document.querySelector("#dobasEVEN");
let dobasODD = document.querySelector("#dobasODD");
let dobasSTREAK = document.querySelector("#dobasSTREAK");

// Általános függvények

function TombGeneralo(tombHossza) {
    let tomb = [];
    for (i = 0; i < tombHossza; i++) {
        tomb.push(0)
    } return tomb
}

// Dobás függvények

function Kockadobas() {

    dobasGombDB++;
    let dobas = [0]; // Elemei 0: összeg, 1: első kocka, 2: második kocka, stb
    kockakSzama = document.querySelector("#kockaMennyiseg").value;
    let sum = 0;

    for (i = 1; i <= 10; i++) {
        document.querySelector(`#kockaImg${i}`).style.backgroundImage = "none"
    }
    for (i = 1; i <= kockakSzama; i++) {
        let szam = Math.round(Math.random() * 5) + 1;
        sum += szam;
        kockaEredmenyDB[szam - 1]++
        dobas.push(szam);
        document.querySelector(`#kockaImg${i}`).style.backgroundImage = `url(Dobokocka/img/${szam}.png)`
    }
    dobas[0] = sum;
    dobasok.push(dobas);

    if (dobasGombDB == 1) { dobasErtekSzamlalo = TombGeneralo(Number(kockakSzama * 6) + 1) }
    dobasErtekSzamlalo[sum]++;

}

dobasGomb.addEventListener("click", DobasGomgFuttatas);

dobasGomb100.addEventListener("click", DobasGomgFuttatas100);

function DobasGomgFuttatas100() {
    for (i = 0; i < 5; i++) {

        console.log(i);
        dobasGomb.click();
    }
}


function DobasGomgFuttatas() {
    Kockadobas()
    DobasokAtlaga()
    DobasokMaximuma()
    Dobas666()
    DobasAAA()
    DobasABC()
    DobasEVEN()
    DobasODD()
    DobasSTREAK()

    StatisztikaKiiratas()
}

function DobasokAtlaga() {
    let sum = 0;
    for (i = 0; i < dobasok.length; i++) {
        sum += dobasok[i][0];
    }
    dobasokAtlaga = (sum / dobasok.length).toFixed(2)
}

function DobasokMaximuma() {
    if (dobasok[maxIndex][0] < dobasok[dobasok.length - 1][0]) { maxIndex = dobasok.length - 1 }
}

function Dobas666() {
    let hatosokDB = 0;
    for (i = 0; i < dobasok[dobasok.length - 1].length; i++) {
        if (dobasok[dobasok.length - 1][i] == 6) {
            hatosokDB++
        }
    }
    if (hatosokDB > 2) {
        dobas666DB++
    }
}

function DobasAAA() {
    let ugyanazok = TombGeneralo(6);
    for (i = 1; i < dobasok[dobasok.length - 1].length; i++) {
        ugyanazok[dobasok[dobasok.length - 1][i] - 1]++
    }
    for (i = 0; i < ugyanazok.length; i++) {
        if (ugyanazok[i] > 2) { dobasAAADB++ }
    }
}

function DobasABC() {
    let kulonbozok = TombGeneralo(6);
    for (i = 1; i < dobasok[dobasok.length - 1].length; i++) {
        kulonbozok[dobasok[dobasok.length - 1][i] - 1]++
    }
    let nemNulla = 0;
    for (i = 0; i < kulonbozok.length; i++) {
        if (kulonbozok[i] !== 0) { nemNulla++ }
    }
    if (nemNulla > 2) { dobasABCDB++ }
}

function DobasMOST() {
    let leggyakoribbErtek = kockakSzama;
    for (i = 1; i < dobasErtekSzamlalo.length; i++) {
        if (dobasErtekSzamlalo[leggyakoribbErtek] < dobasErtekSzamlalo[i]) { leggyakoribbErtek = i }
    }
    return leggyakoribbErtek
}

function DobasRARE() {
    let legitkabbErtek = kockakSzama;
    for (i = 1; i < dobasErtekSzamlalo.length; i++) {
        if (dobasErtekSzamlalo[legitkabbErtek] > dobasErtekSzamlalo[i]) { legitkabbErtek = i }
    }
    return legitkabbErtek
}

function DobasEVEN() {
    for (i = 1; i < dobasok[dobasok.length - 1].length; i++) {
        if (dobasok[dobasok.length - 1][i] % 2 == 0) { dobasEVENDB++ }
    }
}

function DobasODD() {
    for (i = 1; i < dobasok[dobasok.length - 1].length; i++) {
        if (dobasok[dobasok.length - 1][i] % 2 == 1) { dobasODDDB++ }
    }
}

function DobasSTREAK() {
    let dobasokEgyszer = [];
    for (i = 1; i < dobasok[dobasok.length - 1].length; i++) {
        let iter = false;
        for (j = 0; j < dobasokEgyszer.length; j++) {
            if (dobasok[dobasok.length - 1][i] == dobasokEgyszer[j]) { iter = true }
        }
        if (iter == false) { dobasokEgyszer.push(dobasok[dobasok.length - 1][i]) }
    }
    let dobasokEgyszerRendezve = dobasokEgyszer.sort(function (a, b) { return a - b }).toString();
    if (dobasokEgyszerRendezve.includes("1,2,3") || dobasokEgyszerRendezve.includes("2,3,4") || dobasokEgyszerRendezve.includes("3,4,5") || dobasokEgyszerRendezve.includes("4,5,6")) { dobasSTREAKDB++ }


}

function StatisztikaKiiratas() {
    egyszerreDobasDB.innerHTML = dobasok.length;
    egyszerreDobasSUM.innerHTML = dobasok[dobasok.length - 1][0];
    document.querySelector("#egyesDB").innerHTML = kockaEredmenyDB[0];
    document.querySelector("#kettesDB").innerHTML = kockaEredmenyDB[1];
    document.querySelector("#harmasDB").innerHTML = kockaEredmenyDB[2];
    document.querySelector("#negyesDB").innerHTML = kockaEredmenyDB[3];
    document.querySelector("#otosDB").innerHTML = kockaEredmenyDB[4];
    document.querySelector("#hatosDB").innerHTML = kockaEredmenyDB[5];
    dobasSUMAVG.innerHTML = dobasokAtlaga;
    dobasSUMTOP.innerHTML = dobasok[maxIndex][0];
    dobas666.innerHTML = dobas666DB;
    dobasAAA.innerHTML = dobasAAADB;
    dobasABC.innerHTML = dobasABCDB;
    dobasMOST.innerHTML = DobasMOST();
    dobasRARE.innerHTML = DobasRARE();
    dobasEVEN.innerHTML = (dobasEVENDB / (dobasok.length * kockakSzama) * 100).toFixed(2);
    dobasODD.innerHTML = dobasODDDB;
    dobasSTREAK.innerHTML = dobasSTREAKDB;
}


document.querySelector("#kockaMennyiseg").addEventListener("input", UjraInditas);

function UjraInditas() {
    alert("RESET! Statisztikai eredmények törlődnek!");
    dobasok = [];
    dobasGombDB = 0;
    kockakSzama = 3;
    dobasokAtlaga = 0;
    maxIndex = 0;
    kockaEredmenyDB = TombGeneralo(6);
    dobas666DB = 0;
    dobasAAADB = 0;
    dobasABCDB = 0;
    dobasErtekSzamlalo = [];
    dobasEVENDB = 0;
    dobasODDDB = 0;
    dobasSTREAKDB = 0;
    for (i = 1; i <= 10; i++) {
        document.querySelector(`#kockaImg${i}`).style.backgroundImage = "none"
    }
    egyszerreDobasDB.innerHTML = 0;
    egyszerreDobasSUM.innerHTML = 0;
    document.querySelector("#egyesDB").innerHTML = 0;
    document.querySelector("#kettesDB").innerHTML = 0;
    document.querySelector("#harmasDB").innerHTML = 0;
    document.querySelector("#negyesDB").innerHTML = 0;
    document.querySelector("#otosDB").innerHTML = 0;
    document.querySelector("#hatosDB").innerHTML = 0;
    dobasSUMAVG.innerHTML = 0;
    dobasSUMTOP.innerHTML = 0;
    dobas666.innerHTML = 0;
    dobasAAA.innerHTML = 0;
    dobasABC.innerHTML = 0;
    dobasMOST.innerHTML = 0;
    dobasRARE.innerHTML = 0;
    dobasEVEN.innerHTML = 0;
    dobasODD.innerHTML = 0;
}
