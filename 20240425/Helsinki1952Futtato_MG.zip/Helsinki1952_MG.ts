let helsinki = [
    "1 1 atletika kalapacsvetes",
    "1 1 uszas 400m_gyorsuszas",
    "1 1 birkozas kotott_fogas_legsuly",
    "1 1 torna talajtorna",
    "1 1 torna felemas_korlat",
    "1 1 vivas kardvivas_egyeni",
    "1 1 okolvivas nagyvaltosuly",
    "1 1 uszas 200m_melluszas",
    "1 1 birkozas kotott_fogas_valtosuly",
    "1 1 uszas 100m_gyorsuszas",
    "1 1 sportloveszet onmukodo_sportpisztoly",
    "1 15 labdarugas ferfi_csapat",
    "1 3 ottusa ferfi_csapat",
    "1 6 vivas kardvivas_csapat",
    "1 5 uszas 4x100m_gyorsuszo_valto",
    "1 13 vizilabda ferfi_csapat",
    "2 1 ottusa ottusa_egyeni",
    "2 1 vivas torvivas_egyeni",
    "2 1 vivas kardvivas_egyeni",
    "2 1 sportloveszet onmukodo_sportpisztoly",
    "2 1 uszas 400m_gyorsuszas",
    "2 1 uszas 200m_melluszas",
    "2 1 kajakkenu kenu_egyes_10000m",
    "2 1 kajakkenu kajak_egyes_1000m",
    "2 1 birkozas kotott_fogas_pehelysuly",
    "2 8 torna noi_osszetett_csapat",
    "3 1 sportloveszet sportpisztoly",
    "3 1 vivas kardvivas_egyeni",
    "3 1 atletika tavolugras",
    "3 1 birkozas szabad_fogas_kozepsuly",
    "3 1 torna felemas_korlat",
    "3 1 torna osszetett_egyeni",
    "3 1 torna gerenda",
    "3 1 torna talajtorna",
    "3 1 atletika kalapacsvetes",
    "3 1 atletika 50km_gyaloglas",
    "3 1 ottusa ottusa_egyeni",
    "3 1 uszas 100m_gyorsuszas",
    "3 4 atletika 4x100m_valtofutas",
    "3 2 kajakkenu kenu_kettes_10000m",
    "3 8 torna keziszer_csapat",
    "3 6 vivas torvivas_csapat",
    "4 1 torna gerenda",
    "4 1 uszas 200m_mell",
    "4 1 birkozas kotottfogas_felnehezsuly",
    "4 1 torna talaj",
    "4 1 birkozas kotottfogas_kozepsuly",
    "4 1 birkozas kotottfogas_konnyusuly",
    "5 1 okolvivas pehelysuly",
    "5 1 okolvivas konnyusuly",
    "5 1 uszas 100m_gyors",
    "5 1 atletika diszkoszvetes",
    "5 1 vivas parbajtor_egyeni",
    "5 2 kajak-kenu kenu_kettes_1000m",
    "5 2 kerekparozas ketuleses_verseny",
    "5 4 uszas 4x200m_gyorsvalto",
    "5 5 vivas parbajtor_csapat",
    "6 1 birkozas kotottfogas_legsuly",
    "6 1 kajak-kenu kajak_egyes_500m",
    "6 1 torna osszetett_egyeni",
    "6 1 kerekparozas repuloverseny",
    "6 1 uszas 400m_gyors",
    "6 1 torna felemaskorlat",
    "6 8 torna osszetett_csapat"
]

// Adatátalakítás

interface helsinkiMinta {
    helyezes: number,
    sportolokSzama: number,
    sportag: string,
    versenyszam: string
}

function AdatAtalakito(vizsgaltTomb: string[]): helsinkiMinta[] {
    let helsinkiTomb: helsinkiMinta[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let adatSzetszedve: string[] = vizsgaltTomb[i].split(" ");
        let adatOsszerakva: helsinkiMinta = {
            helyezes: Number(adatSzetszedve[0]),
            sportolokSzama: Number(adatSzetszedve[1]),
            sportag: String(adatSzetszedve[2]),
            versenyszam: String(adatSzetszedve[3])
        }
        helsinkiTomb.push(adatOsszerakva)
    }
    return helsinkiTomb
}

let helsinkiTomb: helsinkiMinta[] = AdatAtalakito(helsinki);

console.log(helsinkiTomb);

// 3. Feladat Határozza meg és írja ki a képernyőre a minta szerint, hogy hány pontszerző helyezéstértekel a magyar olimpikonok!

document.write(`3. feladat: <br> Pontszerző helyezések száma: ${helsinkiTomb.length}<br>`)

// 4. Feladat Készítsen statisztikát a  megszerzett érmek számáról, majd   összesítse az érmek    számát aminta szerint!

function AranyakSzama(vizsgaltTomb: helsinkiMinta[]): number {
    let aranyakSzama: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].helyezes == 1) { aranyakSzama++ }
    }
    return aranyakSzama
}

function EzustokSzama(vizsgaltTomb: helsinkiMinta[]): number {
    let ezustokSzama: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].helyezes == 2) { ezustokSzama++ }
    }
    return ezustokSzama
}

function BronzokSzama(vizsgaltTomb: helsinkiMinta[]): number {
    let bronzokSzama: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].helyezes == 3) { bronzokSzama++ }
    }
    return bronzokSzama
}

document.write(`4. feladat: <br> Arany: ${AranyakSzama(helsinkiTomb)}<br>Ezüst: ${EzustokSzama(helsinkiTomb)}<br>Bronz: ${BronzokSzama(helsinkiTomb)}<br>Összesen: ${AranyakSzama(helsinkiTomb) + EzustokSzama(helsinkiTomb) + BronzokSzama(helsinkiTomb)}<br>`);

// 5. Feladat Az olimpián az országokat az elért eredményeik alapján rangsorolják. Az 1−6.helyezéseket olimpiai pontokra váltják, és ezt összegzik. Határozza meg és írja ki a mintaszerint az elért olimpiai pontok összegét az alábbi táblázat segítségével

function OlimpiaiPontszamok(vizsgaltTomb: helsinkiMinta[]): number {
    let olimpiaiPontok: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].helyezes == 1) { olimpiaiPontok += 7 }
        else if (vizsgaltTomb[i].helyezes == 2) { olimpiaiPontok += 5 }
        else if (vizsgaltTomb[i].helyezes == 3) { olimpiaiPontok += 4 }
        else if (vizsgaltTomb[i].helyezes == 4) { olimpiaiPontok += 3 }
        else if (vizsgaltTomb[i].helyezes == 5) { olimpiaiPontok += 2 }
        else { olimpiaiPontok += 1 }
    }
    return olimpiaiPontok
}

document.write(`5. feladat: <br> Olimpiai pontok száma: ${OlimpiaiPontszamok(helsinkiTomb)}<br>`)

// 6. Feladat Az úszás és a torna sportágakban világversenyeken mindig jól szerepeltek a magyarsportolók. Határozza meg és írja ki a minta szerint, hogy az 1952-es nyári olimpiánmelyiksportágban szereztek több érmet a sportolók! Ha az érmek száma egyenlő, akkor az„Egyenlő volt az érmek száma” felirat jelenjen meg!

function UszasErmek(vizsgaltTomb: helsinkiMinta[]): number {
    let uszasErmek: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].helyezes <= 3 && vizsgaltTomb[i].sportag == "uszas") { uszasErmek++ }

    }
    return uszasErmek
}

function TornaErmek(vizsgaltTomb: helsinkiMinta[]): number {
    let tornaErmek: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].helyezes <= 3 && vizsgaltTomb[i].sportag == "torna") { tornaErmek++ }

    }
    return tornaErmek
}

function KiiratoHatos(): void {
    let uszasErmek: number = UszasErmek(helsinkiTomb);
    let tornaErmek: number = TornaErmek(helsinkiTomb);
    if (uszasErmek > tornaErmek) { document.write(`6. feladat: <br>Uszás sportágban szereztek több érmet<br>`) }
    if (uszasErmek < tornaErmek) { document.write(`6. feladat: <br>Torna sportágban szereztek több érmet<br>`) }
    if (uszasErmek == tornaErmek) { document.write(`6. feladat: <br>Egyenlő volt az érmek száma<br>`) }
}

KiiratoHatos();

// 7. Feladat A helsinkiAdatok.js állományba hibásan, egybeírva „kajakkenu” került a kajak-kenusportág neve. Készítsen egy tömböthelsinki2néven, amelybe helyesen,kötőjellelkerül a sportág neve! Az új adatszerkezet tartalmazzon minden helyezést aforrásállományból, a sportágak neve elé kerüljön be a megszerzett olimpiai pont is! Asorokban az adatokat szóközzel válassza el egymástól!

interface helsinki2Minta {
    helyezes: number,
    sportolokSzama: number,
    olimpiaiPont: number,
    sportag: string,
    versenyszam: string
}

function OlimpiaiPontSzamolo(helyezes: number): number {
    if (helyezes == 1) { return 7 }
    if (helyezes == 2) { return 5 }
    if (helyezes == 3) { return 4 }
    if (helyezes == 4) { return 3 }
    if (helyezes == 5) { return 2 }
    if (helyezes == 6) { return 1 }
}

function AdatAtalakito2(vizsgaltTomb: helsinkiMinta[]): helsinki2Minta[] {
    let helsinki2Tomb: helsinki2Minta[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].sportag == "kajakkenu") { vizsgaltTomb[i].sportag = "kajak-kenu" }
        let adatOsszerakva: helsinki2Minta = {
            helyezes: vizsgaltTomb[i].helyezes,
            sportolokSzama: vizsgaltTomb[i].sportolokSzama,
            olimpiaiPont: OlimpiaiPontSzamolo(vizsgaltTomb[i].helyezes),
            sportag: vizsgaltTomb[i].sportag,
            versenyszam: vizsgaltTomb[i].versenyszam
        }
        helsinki2Tomb.push(adatOsszerakva)
    }
    return helsinki2Tomb
}

let helsinki2Tomb: helsinki2Minta = AdatAtalakito2(helsinkiTomb);

console.log(helsinki2Tomb)

// 8 Feladat Határozza meg, hogy melyik pontszerző helyezéshez fűződik a legtöbb sportoló! Írja ki aminta szerint a helyezést, a sportágat, a versenyszámot és a sportolók számát!Feltételezheti, hogy nem alakult ki holtverseny

function MaxSportolo(vizsgaltTomb: helsinki2Minta[]): number {
    let maxSportoloIndex: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].sportolokSzama > vizsgaltTomb[maxSportoloIndex].sportolokSzama) { maxSportoloIndex = i }
    }
    return maxSportoloIndex
}

document.write(`8. feladat: <br> Helyezés: ${helsinki2Tomb[MaxSportolo(helsinki2Tomb)].helyezes}<br>Sportág: ${helsinki2Tomb[MaxSportolo(helsinki2Tomb)].sportag}<br>Versenyszám: ${helsinki2Tomb[MaxSportolo(helsinki2Tomb)].versenyszam}<br>Sportolók száma: ${helsinki2Tomb[MaxSportolo(helsinki2Tomb)].sportolokSzama}<br>`);
