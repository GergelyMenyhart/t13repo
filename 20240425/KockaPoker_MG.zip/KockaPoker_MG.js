// Értékek
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35;
var dobas = [0, 0, 0, 0, 0];
var dobasDB = 0;
var dobasSum = 0;
var playerDB = 1;
var playerActual = 1;
var player1 = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player2 = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player3 = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player4 = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player1Sum = 0;
var player2Sum = 0;
var player3Sum = 0;
var player4Sum = 0;
// Hivatkozások
var jatekosMennyiseg = document.querySelector("#jatekosMennyiseg");
var kockaDobasDom = document.querySelector("#kockaDobas");
var kockaMegjegyzesDom = document.querySelector("#megjegyzes");
var kocka1Dom = document.querySelector("#kockaImg1");
var kocka2Dom = document.querySelector("#kockaImg2");
var kocka3Dom = document.querySelector("#kockaImg3");
var kocka4Dom = document.querySelector("#kockaImg4");
var kocka5Dom = document.querySelector("#kockaImg5");
// Figyelések
jatekosMennyiseg === null || jatekosMennyiseg === void 0 ? void 0 : jatekosMennyiseg.addEventListener("click", JatekosSzamKiolvasas);
kockaDobasDom === null || kockaDobasDom === void 0 ? void 0 : kockaDobasDom.addEventListener("click", DobasGomb);
kocka1Dom === null || kocka1Dom === void 0 ? void 0 : kocka1Dom.addEventListener("click", function () { Dobas1Kocka(1); });
kocka2Dom === null || kocka2Dom === void 0 ? void 0 : kocka2Dom.addEventListener("click", function () { Dobas1Kocka(2); });
kocka3Dom === null || kocka3Dom === void 0 ? void 0 : kocka3Dom.addEventListener("click", function () { Dobas1Kocka(3); });
kocka4Dom === null || kocka4Dom === void 0 ? void 0 : kocka4Dom.addEventListener("click", function () { Dobas1Kocka(4); });
kocka5Dom === null || kocka5Dom === void 0 ? void 0 : kocka5Dom.addEventListener("click", function () { Dobas1Kocka(5); });
// Általános függvények
function JatekosSzamKiolvasas() {
    playerDB = jatekosMennyiseg.value;
    console.log(playerDB);
}
function JatekosHatarozo(jatekosIndex) {
    if (jatekosIndex == 1) {
        return player1;
    }
    if (jatekosIndex == 2) {
        return player2;
    }
    if (jatekosIndex == 3) {
        return player3;
    }
    if (jatekosIndex == 4) {
        return player4;
    }
}
function JatekosSumHatarozo(jatekosIndex) {
    if (jatekosIndex == 1) {
        return player1Sum;
    }
    if (jatekosIndex == 2) {
        return player2Sum;
    }
    if (jatekosIndex == 3) {
        return player3Sum;
    }
    if (jatekosIndex == 4) {
        return player4Sum;
    }
}
// Kockakezelés
function Dobas5Kocka() {
    dobas = [0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobas[i] = Number(Math.ceil(Math.random() * 6));
    }
    console.log(dobas);
}
function Dobas1Kocka(kockaId) {
    dobas[kockaId - 1] = Number(Math.ceil(Math.random() * 6));
    document.querySelector("#kockaImg".concat(kockaId)).style.opacity = 0.6;
    console.log(dobas);
}
function DobasGomb() {
    dobasDB++;
    jatekosMennyiseg.disabled = true;
    if (dobasDB == 1) {
        Dobas5Kocka();
        for (var i = 0; i < dobas.length; i++) {
            document.querySelector("#kockaImg".concat(i + 1)).style.backgroundImage = "url(img/".concat(dobas[i], ".png)");
            document.querySelector("#kockaImg".concat(i + 1)).style.opacity = 1;
        }
        kockaDobasDom.innerHTML = "Kockadobas 3/1";
        kockaMegjegyzesDom === null || kockaMegjegyzesDom === void 0 ? void 0 : kockaMegjegyzesDom.innerHTML = "V\u00E1laszd ki azokat a kock\u00E1kat, melyeket \u00FAjradobn\u00E1l! Vagy v\u00E1lassz a j\u00E1t\u00E9koslapr\u00F3l!";
    }
    if (dobasDB == 2) {
        for (var i = 0; i < dobas.length; i++) {
            document.querySelector("#kockaImg".concat(i + 1)).style.backgroundImage = "url(img/".concat(dobas[i], ".png)");
            document.querySelector("#kockaImg".concat(i + 1)).style.opacity = 1;
        }
        kockaDobasDom.innerHTML = "Kockadobas 3/2";
        kockaMegjegyzesDom === null || kockaMegjegyzesDom === void 0 ? void 0 : kockaMegjegyzesDom.innerHTML = "V\u00E1laszd ki azokat a kock\u00E1kat, melyeket \u00FAjradobn\u00E1l! Vagy v\u00E1lassz a j\u00E1t\u00E9koslapr\u00F3l!";
    }
    if (dobasDB == 3) {
        for (var i = 0; i < dobas.length; i++) {
            document.querySelector("#kockaImg".concat(i + 1)).style.backgroundImage = "url(img/".concat(dobas[i], ".png)");
            document.querySelector("#kockaImg".concat(i + 1)).style.opacity = 1;
        }
        kockaDobasDom.innerHTML = "Kockadobas 3/3";
        kockaDobasDom.disabled = true;
        kockaMegjegyzesDom === null || kockaMegjegyzesDom === void 0 ? void 0 : kockaMegjegyzesDom.innerHTML = "V\u00E1lassz a j\u00E1t\u00E9koslapr\u00F3l!";
    }
}
function KockadobasReset() {
    kockaDobasDom.innerHTML = "Kockadobas";
    kockaDobasDom.disabled = false;
    kockaMegjegyzesDom === null || kockaMegjegyzesDom === void 0 ? void 0 : kockaMegjegyzesDom.innerHTML = "\u00DAj k\u00F6rt kezd\u0151d\u00F6tt! Dobj!";
    dobas = [0, 0, 0, 0, 0];
    dobasDB = 0;
}
function KockaEltuntetes() {
    for (var i = 0; i < dobas.length; i++) {
        document.querySelector("#kockaImg".concat(i + 1)).style.opacity = 0;
    }
}
// Játéklap figyelés
KockaEltuntetes();
JatekoslapDeaktivalo();
JatekoslapAktivalo(1);
function JatekoslapDeaktivalo() {
    var _a, _b, _c, _d;
    for (var i = 1; i <= 4; i++) {
        (_a = document.querySelector("#jatekos".concat(i))) === null || _a === void 0 ? void 0 : _a.classList.remove("fw-bold");
        (_b = document.querySelector("#jatekos".concat(i))) === null || _b === void 0 ? void 0 : _b.classList.add("fw-normal");
        (_c = document.querySelector("#sump".concat(i))) === null || _c === void 0 ? void 0 : _c.classList.remove("fw-bold");
        (_d = document.querySelector("#sump".concat(i))) === null || _d === void 0 ? void 0 : _d.classList.add("fw-normal");
        document.querySelector("#btnp".concat(i, "haz1")).disabled = true;
        document.querySelector("#btnp".concat(i, "haz2")).disabled = true;
        document.querySelector("#btnp".concat(i, "haz3")).disabled = true;
        document.querySelector("#btnp".concat(i, "haz4")).disabled = true;
        document.querySelector("#btnp".concat(i, "haz5")).disabled = true;
        document.querySelector("#btnp".concat(i, "haz6")).disabled = true;
        document.querySelector("#btnp".concat(i, "par")).disabled = true;
        document.querySelector("#btnp".concat(i, "ketpar")).disabled = true;
        document.querySelector("#btnp".concat(i, "drill")).disabled = true;
        document.querySelector("#btnp".concat(i, "full")).disabled = true;
        document.querySelector("#btnp".concat(i, "poker")).disabled = true;
        document.querySelector("#btnp".concat(i, "kissor")).disabled = true;
        document.querySelector("#btnp".concat(i, "nagysor")).disabled = true;
        document.querySelector("#btnp".concat(i, "nagypoker")).disabled = true;
        document.querySelector("#btnp".concat(i, "szemet")).disabled = true;
    }
}
function JatekoslapAktivalo(i) {
    var _a, _b, _c, _d;
    var jatekos = JatekosHatarozo(i);
    (_a = document.querySelector("#jatekos".concat(i))) === null || _a === void 0 ? void 0 : _a.classList.remove("fw-normal");
    (_b = document.querySelector("#jatekos".concat(i))) === null || _b === void 0 ? void 0 : _b.classList.add("fw-bold");
    (_c = document.querySelector("#sump".concat(i))) === null || _c === void 0 ? void 0 : _c.classList.remove("fw-normal");
    (_d = document.querySelector("#sump".concat(i))) === null || _d === void 0 ? void 0 : _d.classList.add("fw-bold");
    document.querySelector("#btnp".concat(i, "haz1")).disabled = jatekos[0];
    document.querySelector("#btnp".concat(i, "haz2")).disabled = jatekos[1];
    document.querySelector("#btnp".concat(i, "haz3")).disabled = jatekos[2];
    document.querySelector("#btnp".concat(i, "haz4")).disabled = jatekos[3];
    document.querySelector("#btnp".concat(i, "haz5")).disabled = jatekos[4];
    document.querySelector("#btnp".concat(i, "haz6")).disabled = jatekos[5];
    document.querySelector("#btnp".concat(i, "par")).disabled = jatekos[6];
    document.querySelector("#btnp".concat(i, "ketpar")).disabled = jatekos[7];
    document.querySelector("#btnp".concat(i, "drill")).disabled = jatekos[8];
    document.querySelector("#btnp".concat(i, "full")).disabled = jatekos[9];
    document.querySelector("#btnp".concat(i, "poker")).disabled = jatekos[10];
    document.querySelector("#btnp".concat(i, "kissor")).disabled = jatekos[11];
    document.querySelector("#btnp".concat(i, "nagysor")).disabled = jatekos[12];
    document.querySelector("#btnp".concat(i, "nagypoker")).disabled = jatekos[13];
    document.querySelector("#btnp".concat(i, "szemet")).disabled = jatekos[14];
    var keszAHaz = KeszHazVizsgalo(jatekos);
    if (keszAHaz == false) {
        document.querySelector("#btnp".concat(i, "par")).disabled = true;
        document.querySelector("#btnp".concat(i, "ketpar")).disabled = true;
        document.querySelector("#btnp".concat(i, "drill")).disabled = true;
        document.querySelector("#btnp".concat(i, "full")).disabled = true;
        document.querySelector("#btnp".concat(i, "poker")).disabled = true;
        document.querySelector("#btnp".concat(i, "kissor")).disabled = true;
        document.querySelector("#btnp".concat(i, "nagysor")).disabled = true;
        document.querySelector("#btnp".concat(i, "nagypoker")).disabled = true;
        document.querySelector("#btnp".concat(i, "szemet")).disabled = true;
    }
}
function KeszHazVizsgalo(jatekos) {
    var hazKeszSum = 0;
    for (var i = 0; i <= 5; i++) {
        if (jatekos[i] == true) {
            hazKeszSum++;
        }
    }
    if (hazKeszSum == 6) {
        return true;
    }
    else {
        return false;
    }
}
function JatekosLepteto() {
    if (playerActual == playerDB) {
        playerActual = 1;
    }
    else {
        playerActual++;
    }
    JatekoslapDeaktivalo();
    JatekoslapAktivalo(playerActual);
    KockadobasReset();
    KockaEltuntetes();
    dobasSum++;
    if (dobasSum == (playerDB * 15)) {
        kockaMegjegyzesDom === null || kockaMegjegyzesDom === void 0 ? void 0 : kockaMegjegyzesDom.innerHTML = "V\u00E9get \u00E9rt a j\u00E1t\u00E9k! K\u00F6sz\u00F6n\u00F6m!";
    }
}
// Gombvizsgálat függvények
function HazVizsgalatP1(jatekosIndex, melyikTripla) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    player1Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function HazVizsgalatP2(jatekosIndex, melyikTripla) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    player2Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function HazVizsgalatP3(jatekosIndex, melyikTripla) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    player3Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function HazVizsgalatP4(jatekosIndex, melyikTripla) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    player4Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function ParVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player1Sum += (i * dobasErtekDB[i]);
            break;
        }
    }
    jatekos[6] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function ParVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player2Sum += (i * dobasErtekDB[i]);
            break;
        }
    }
    jatekos[6] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function ParVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player3Sum += (i * dobasErtekDB[i]);
            break;
        }
    }
    jatekos[6] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function ParVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player4Sum += (i * dobasErtekDB[i]);
            break;
        }
    }
    jatekos[6] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function KetParVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var parokSzama = 0;
    var pontErtek = 0;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama++;
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) {
        player1Sum += pontErtek;
    }
    jatekos[7] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function KetParVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var parokSzama = 0;
    var pontErtek = 0;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama++;
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) {
        player2Sum += pontErtek;
    }
    jatekos[7] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function KetParVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var parokSzama = 0;
    var pontErtek = 0;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama++;
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) {
        player3Sum += pontErtek;
    }
    jatekos[7] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function KetParVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var parokSzama = 0;
    var pontErtek = 0;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama++;
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) {
        player4Sum += pontErtek;
    }
    jatekos[7] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function DrillVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player1Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function DrillVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player2Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function DrillVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player3Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function DrillVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player4Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function FullVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var fullSum = 0;
    var full3 = false;
    var full2 = false;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) {
        player1Sum += fullSum;
    }
    jatekos[9] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function FullVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var fullSum = 0;
    var full3 = false;
    var full2 = false;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) {
        player2Sum += fullSum;
    }
    jatekos[9] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function FullVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var fullSum = 0;
    var full3 = false;
    var full2 = false;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) {
        player3Sum += fullSum;
    }
    jatekos[9] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function FullVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    var fullSum = 0;
    var full3 = false;
    var full2 = false;
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) {
        player4Sum += fullSum;
    }
    jatekos[9] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function PokerVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player1Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function PokerVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player2Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function PokerVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player3Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function PokerVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player4Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function KissorVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var egyes = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) {
            egyes = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (egyes && kettes && harmas && negyes && otos) {
        player1Sum += 15;
    }
    jatekos[11] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function KissorVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var egyes = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) {
            egyes = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (egyes && kettes && harmas && negyes && otos) {
        player2Sum += 15;
    }
    jatekos[11] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function KissorVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var egyes = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) {
            egyes = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (egyes && kettes && harmas && negyes && otos) {
        player3Sum += 15;
    }
    jatekos[11] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function KissorVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var egyes = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) {
            egyes = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (egyes && kettes && harmas && negyes && otos) {
        player4Sum += 15;
    }
    jatekos[11] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function NagysorVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var hatos = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) {
            hatos = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (hatos && kettes && harmas && negyes && otos) {
        player1Sum += 20;
    }
    jatekos[12] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function NagysorVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var hatos = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) {
            hatos = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (hatos && kettes && harmas && negyes && otos) {
        player2Sum += 20;
    }
    jatekos[12] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function NagysorVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var hatos = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) {
            hatos = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (hatos && kettes && harmas && negyes && otos) {
        player3Sum += 20;
    }
    jatekos[12] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function NagysorVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var hatos = false;
    var kettes = false;
    var harmas = false;
    var negyes = false;
    var otos = false;
    for (var i = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) {
            hatos = true;
        }
        if (dobas[i] == 2) {
            kettes = true;
        }
        if (dobas[i] == 3) {
            harmas = true;
        }
        if (dobas[i] == 4) {
            negyes = true;
        }
        if (dobas[i] == 5) {
            otos = true;
        }
    }
    if (hatos && kettes && harmas && negyes && otos) {
        player4Sum += 20;
    }
    jatekos[12] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function NagyPokerVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player1Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function NagyPokerVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player2Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function NagyPokerVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player3Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function NagyPokerVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    var dobasErtekDB = [0, 0, 0, 0, 0, 0, 0];
    for (var i = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++;
    }
    for (var i = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player4Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
function SzemetVizsgalatP1(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    for (var i = 0; i < dobas.length; i++) {
        player1Sum += dobas[i];
    }
    jatekos[14] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player1Sum;
    JatekosLepteto();
}
function SzemetVizsgalatP2(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    for (var i = 0; i < dobas.length; i++) {
        player2Sum += dobas[i];
    }
    jatekos[14] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player2Sum;
    JatekosLepteto();
}
function SzemetVizsgalatP3(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    for (var i = 0; i < dobas.length; i++) {
        player3Sum += dobas[i];
    }
    jatekos[14] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player3Sum;
    JatekosLepteto();
}
function SzemetVizsgalatP4(jatekosIndex) {
    var _a;
    var jatekos = JatekosHatarozo(jatekosIndex);
    for (var i = 0; i < dobas.length; i++) {
        player4Sum += dobas[i];
    }
    jatekos[14] = true;
    (_a = document.querySelector("#sump".concat(jatekosIndex))) === null || _a === void 0 ? void 0 : _a.innerHTML = player4Sum;
    JatekosLepteto();
}
// Gombfigyelés
(_a = document.querySelector("#btnp1haz1")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", function () { HazVizsgalatP1(1, 1); });
(_b = document.querySelector("#btnp2haz1")) === null || _b === void 0 ? void 0 : _b.addEventListener("click", function () { HazVizsgalatP2(2, 1); });
(_c = document.querySelector("#btnp3haz1")) === null || _c === void 0 ? void 0 : _c.addEventListener("click", function () { HazVizsgalatP3(3, 1); });
(_d = document.querySelector("#btnp4haz1")) === null || _d === void 0 ? void 0 : _d.addEventListener("click", function () { HazVizsgalatP4(4, 1); });
(_e = document.querySelector("#btnp1haz2")) === null || _e === void 0 ? void 0 : _e.addEventListener("click", function () { HazVizsgalatP1(1, 2); });
(_f = document.querySelector("#btnp2haz2")) === null || _f === void 0 ? void 0 : _f.addEventListener("click", function () { HazVizsgalatP2(2, 2); });
(_g = document.querySelector("#btnp3haz2")) === null || _g === void 0 ? void 0 : _g.addEventListener("click", function () { HazVizsgalatP3(3, 2); });
(_h = document.querySelector("#btnp4haz2")) === null || _h === void 0 ? void 0 : _h.addEventListener("click", function () { HazVizsgalatP4(4, 2); });
(_j = document.querySelector("#btnp1haz3")) === null || _j === void 0 ? void 0 : _j.addEventListener("click", function () { HazVizsgalatP1(1, 3); });
(_k = document.querySelector("#btnp2haz3")) === null || _k === void 0 ? void 0 : _k.addEventListener("click", function () { HazVizsgalatP2(2, 3); });
(_l = document.querySelector("#btnp3haz3")) === null || _l === void 0 ? void 0 : _l.addEventListener("click", function () { HazVizsgalatP3(3, 3); });
(_m = document.querySelector("#btnp4haz3")) === null || _m === void 0 ? void 0 : _m.addEventListener("click", function () { HazVizsgalatP4(4, 3); });
(_o = document.querySelector("#btnp1haz4")) === null || _o === void 0 ? void 0 : _o.addEventListener("click", function () { HazVizsgalatP1(1, 4); });
(_p = document.querySelector("#btnp2haz4")) === null || _p === void 0 ? void 0 : _p.addEventListener("click", function () { HazVizsgalatP2(2, 4); });
(_q = document.querySelector("#btnp3haz4")) === null || _q === void 0 ? void 0 : _q.addEventListener("click", function () { HazVizsgalatP3(3, 4); });
(_r = document.querySelector("#btnp4haz4")) === null || _r === void 0 ? void 0 : _r.addEventListener("click", function () { HazVizsgalatP4(4, 4); });
(_s = document.querySelector("#btnp1haz5")) === null || _s === void 0 ? void 0 : _s.addEventListener("click", function () { HazVizsgalatP1(1, 5); });
(_t = document.querySelector("#btnp2haz5")) === null || _t === void 0 ? void 0 : _t.addEventListener("click", function () { HazVizsgalatP2(2, 5); });
(_u = document.querySelector("#btnp3haz5")) === null || _u === void 0 ? void 0 : _u.addEventListener("click", function () { HazVizsgalatP3(3, 5); });
(_v = document.querySelector("#btnp4haz5")) === null || _v === void 0 ? void 0 : _v.addEventListener("click", function () { HazVizsgalatP4(4, 5); });
(_w = document.querySelector("#btnp1haz6")) === null || _w === void 0 ? void 0 : _w.addEventListener("click", function () { HazVizsgalatP1(1, 6); });
(_x = document.querySelector("#btnp2haz6")) === null || _x === void 0 ? void 0 : _x.addEventListener("click", function () { HazVizsgalatP2(2, 6); });
(_y = document.querySelector("#btnp3haz6")) === null || _y === void 0 ? void 0 : _y.addEventListener("click", function () { HazVizsgalatP3(3, 6); });
(_z = document.querySelector("#btnp4haz6")) === null || _z === void 0 ? void 0 : _z.addEventListener("click", function () { HazVizsgalatP4(4, 6); });
(_0 = document.querySelector("#btnp1par")) === null || _0 === void 0 ? void 0 : _0.addEventListener("click", function () { ParVizsgalatP1(1); });
(_1 = document.querySelector("#btnp2par")) === null || _1 === void 0 ? void 0 : _1.addEventListener("click", function () { ParVizsgalatP2(2); });
(_2 = document.querySelector("#btnp3par")) === null || _2 === void 0 ? void 0 : _2.addEventListener("click", function () { ParVizsgalatP3(3); });
(_3 = document.querySelector("#btnp4par")) === null || _3 === void 0 ? void 0 : _3.addEventListener("click", function () { ParVizsgalatP4(4); });
(_4 = document.querySelector("#btnp1ketpar")) === null || _4 === void 0 ? void 0 : _4.addEventListener("click", function () { KetParVizsgalatP1(1); });
(_5 = document.querySelector("#btnp2ketpar")) === null || _5 === void 0 ? void 0 : _5.addEventListener("click", function () { KetParVizsgalatP2(2); });
(_6 = document.querySelector("#btnp3ketpar")) === null || _6 === void 0 ? void 0 : _6.addEventListener("click", function () { KetParVizsgalatP3(3); });
(_7 = document.querySelector("#btnp4ketpar")) === null || _7 === void 0 ? void 0 : _7.addEventListener("click", function () { KetParVizsgalatP4(4); });
(_8 = document.querySelector("#btnp1drill")) === null || _8 === void 0 ? void 0 : _8.addEventListener("click", function () { DrillVizsgalatP1(1); });
(_9 = document.querySelector("#btnp2drill")) === null || _9 === void 0 ? void 0 : _9.addEventListener("click", function () { DrillVizsgalatP2(2); });
(_10 = document.querySelector("#btnp3drill")) === null || _10 === void 0 ? void 0 : _10.addEventListener("click", function () { DrillVizsgalatP3(3); });
(_11 = document.querySelector("#btnp4drill")) === null || _11 === void 0 ? void 0 : _11.addEventListener("click", function () { DrillVizsgalatP4(4); });
(_12 = document.querySelector("#btnp1full")) === null || _12 === void 0 ? void 0 : _12.addEventListener("click", function () { FullVizsgalatP1(1); });
(_13 = document.querySelector("#btnp2full")) === null || _13 === void 0 ? void 0 : _13.addEventListener("click", function () { FullVizsgalatP2(2); });
(_14 = document.querySelector("#btnp3full")) === null || _14 === void 0 ? void 0 : _14.addEventListener("click", function () { FullVizsgalatP3(3); });
(_15 = document.querySelector("#btnp4full")) === null || _15 === void 0 ? void 0 : _15.addEventListener("click", function () { FullVizsgalatP4(4); });
(_16 = document.querySelector("#btnp1poker")) === null || _16 === void 0 ? void 0 : _16.addEventListener("click", function () { PokerVizsgalatP1(1); });
(_17 = document.querySelector("#btnp2poker")) === null || _17 === void 0 ? void 0 : _17.addEventListener("click", function () { PokerVizsgalatP2(2); });
(_18 = document.querySelector("#btnp3poker")) === null || _18 === void 0 ? void 0 : _18.addEventListener("click", function () { PokerVizsgalatP3(3); });
(_19 = document.querySelector("#btnp4poker")) === null || _19 === void 0 ? void 0 : _19.addEventListener("click", function () { PokerVizsgalatP4(4); });
(_20 = document.querySelector("#btnp1kissor")) === null || _20 === void 0 ? void 0 : _20.addEventListener("click", function () { KissorVizsgalatP1(1); });
(_21 = document.querySelector("#btnp2kissor")) === null || _21 === void 0 ? void 0 : _21.addEventListener("click", function () { KissorVizsgalatP2(2); });
(_22 = document.querySelector("#btnp3kissor")) === null || _22 === void 0 ? void 0 : _22.addEventListener("click", function () { KissorVizsgalatP3(3); });
(_23 = document.querySelector("#btnp4kissor")) === null || _23 === void 0 ? void 0 : _23.addEventListener("click", function () { KissorVizsgalatP4(4); });
(_24 = document.querySelector("#btnp1nagysor")) === null || _24 === void 0 ? void 0 : _24.addEventListener("click", function () { NagysorVizsgalatP1(1); });
(_25 = document.querySelector("#btnp2nagysor")) === null || _25 === void 0 ? void 0 : _25.addEventListener("click", function () { NagysorVizsgalatP2(2); });
(_26 = document.querySelector("#btnp3nagysor")) === null || _26 === void 0 ? void 0 : _26.addEventListener("click", function () { NagysorVizsgalatP3(3); });
(_27 = document.querySelector("#btnp4nagysor")) === null || _27 === void 0 ? void 0 : _27.addEventListener("click", function () { NagysorVizsgalatP4(4); });
(_28 = document.querySelector("#btnp1nagypoker")) === null || _28 === void 0 ? void 0 : _28.addEventListener("click", function () { NagyPokerVizsgalatP1(1); });
(_29 = document.querySelector("#btnp2nagypoker")) === null || _29 === void 0 ? void 0 : _29.addEventListener("click", function () { NagyPokerVizsgalatP2(2); });
(_30 = document.querySelector("#btnp3nagypoker")) === null || _30 === void 0 ? void 0 : _30.addEventListener("click", function () { NagyPokerVizsgalatP3(3); });
(_31 = document.querySelector("#btnp4nagypoker")) === null || _31 === void 0 ? void 0 : _31.addEventListener("click", function () { NagyPokerVizsgalatP4(4); });
(_32 = document.querySelector("#btnp1szemet")) === null || _32 === void 0 ? void 0 : _32.addEventListener("click", function () { SzemetVizsgalatP1(1); });
(_33 = document.querySelector("#btnp2szemet")) === null || _33 === void 0 ? void 0 : _33.addEventListener("click", function () { SzemetVizsgalatP2(2); });
(_34 = document.querySelector("#btnp3szemet")) === null || _34 === void 0 ? void 0 : _34.addEventListener("click", function () { SzemetVizsgalatP3(3); });
(_35 = document.querySelector("#btnp4szemet")) === null || _35 === void 0 ? void 0 : _35.addEventListener("click", function () { SzemetVizsgalatP4(4); });
