// Értékek

var dobas: number[] = [0, 0, 0, 0, 0];
var dobasDB: number = 0;
var dobasSum: number = 0;
var playerDB: number = 1;
var playerActual: number = 1;
var player1: boolean[] = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player2: boolean[] = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player3: boolean[] = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player4: boolean[] = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,];
var player1Sum: number = 0;
var player2Sum: number = 0;
var player3Sum: number = 0;
var player4Sum: number = 0;




// Hivatkozások

var jatekosMennyiseg = document.querySelector("#jatekosMennyiseg")
var kockaDobasDom = document.querySelector("#kockaDobas");
var kockaMegjegyzesDom = document.querySelector("#megjegyzes");
var kocka1Dom = document.querySelector("#kockaImg1");
var kocka2Dom = document.querySelector("#kockaImg2");
var kocka3Dom = document.querySelector("#kockaImg3");
var kocka4Dom = document.querySelector("#kockaImg4");
var kocka5Dom = document.querySelector("#kockaImg5");


// Figyelések

jatekosMennyiseg?.addEventListener("click", JatekosSzamKiolvasas);
kockaDobasDom?.addEventListener("click", DobasGomb);
kocka1Dom?.addEventListener("click", function () { Dobas1Kocka(1) });
kocka2Dom?.addEventListener("click", function () { Dobas1Kocka(2) });
kocka3Dom?.addEventListener("click", function () { Dobas1Kocka(3) });
kocka4Dom?.addEventListener("click", function () { Dobas1Kocka(4) });
kocka5Dom?.addEventListener("click", function () { Dobas1Kocka(5) });



// Általános függvények

function JatekosSzamKiolvasas(): void {
    playerDB = jatekosMennyiseg.value;
    console.log(playerDB);
}

function JatekosHatarozo(jatekosIndex: number): boolean[] {
    if (jatekosIndex == 1) { return player1 }
    if (jatekosIndex == 2) { return player2 }
    if (jatekosIndex == 3) { return player3 }
    if (jatekosIndex == 4) { return player4 }
}

function JatekosSumHatarozo(jatekosIndex: number): number {
    if (jatekosIndex == 1) { return player1Sum }
    if (jatekosIndex == 2) { return player2Sum }
    if (jatekosIndex == 3) { return player3Sum }
    if (jatekosIndex == 4) { return player4Sum }
}


// Kockakezelés

function Dobas5Kocka(): void {
    dobas = [0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobas[i] = Number(Math.ceil(Math.random() * 6))
    }
    console.log(dobas);
}

function Dobas1Kocka(kockaId: number): void {
    dobas[kockaId - 1] = Number(Math.ceil(Math.random() * 6));
    document.querySelector(`#kockaImg${kockaId}`).style.opacity = 0.6;
    console.log(dobas);
}

function DobasGomb(): void {
    dobasDB++;
    jatekosMennyiseg.disabled = true;
    if (dobasDB == 1) {
        Dobas5Kocka();
        for (let i: number = 0; i < dobas.length; i++) {
            document.querySelector(`#kockaImg${i + 1}`).style.backgroundImage = `url(img/${dobas[i]}.png)`;
            document.querySelector(`#kockaImg${i + 1}`).style.opacity = 1;
        }
        kockaDobasDom.innerHTML = `Kockadobas 3/1`;
        kockaMegjegyzesDom?.innerHTML = `Válaszd ki azokat a kockákat, melyeket újradobnál! Vagy válassz a játékoslapról!`;
    }
    if (dobasDB == 2) {
        for (let i: number = 0; i < dobas.length; i++) {
            document.querySelector(`#kockaImg${i + 1}`).style.backgroundImage = `url(img/${dobas[i]}.png)`;
            document.querySelector(`#kockaImg${i + 1}`).style.opacity = 1;
        }
        kockaDobasDom.innerHTML = `Kockadobas 3/2`;
        kockaMegjegyzesDom?.innerHTML = `Válaszd ki azokat a kockákat, melyeket újradobnál! Vagy válassz a játékoslapról!`;
    }
    if (dobasDB == 3) {
        for (let i: number = 0; i < dobas.length; i++) {
            document.querySelector(`#kockaImg${i + 1}`).style.backgroundImage = `url(img/${dobas[i]}.png)`;
            document.querySelector(`#kockaImg${i + 1}`).style.opacity = 1;
        }
        kockaDobasDom.innerHTML = `Kockadobas 3/3`;
        kockaDobasDom.disabled = true;
        kockaMegjegyzesDom?.innerHTML = `Válassz a játékoslapról!`;
    }
}

function KockadobasReset(): void {
    kockaDobasDom.innerHTML = `Kockadobas`;
    kockaDobasDom.disabled = false;
    kockaMegjegyzesDom?.innerHTML = `Új kört kezdődött! Dobj!`;
    dobas = [0, 0, 0, 0, 0];
    dobasDB = 0;
}

function KockaEltuntetes(): void {
    for (let i: number = 0; i < dobas.length; i++) {
        document.querySelector(`#kockaImg${i + 1}`).style.opacity = 0;
    }
}

// Játéklap figyelés

KockaEltuntetes();
JatekoslapDeaktivalo();
JatekoslapAktivalo(1);

function JatekoslapDeaktivalo(): void {
    for (let i: number = 1; i <= 4; i++) {
        document.querySelector(`#jatekos${i}`)?.classList.remove("fw-bold");
        document.querySelector(`#jatekos${i}`)?.classList.add("fw-normal");
        document.querySelector(`#sump${i}`)?.classList.remove("fw-bold");
        document.querySelector(`#sump${i}`)?.classList.add("fw-normal");
        document.querySelector(`#btnp${i}haz1`).disabled = true;
        document.querySelector(`#btnp${i}haz2`).disabled = true;
        document.querySelector(`#btnp${i}haz3`).disabled = true;
        document.querySelector(`#btnp${i}haz4`).disabled = true;
        document.querySelector(`#btnp${i}haz5`).disabled = true;
        document.querySelector(`#btnp${i}haz6`).disabled = true;
        document.querySelector(`#btnp${i}par`).disabled = true;
        document.querySelector(`#btnp${i}ketpar`).disabled = true;
        document.querySelector(`#btnp${i}drill`).disabled = true;
        document.querySelector(`#btnp${i}full`).disabled = true;
        document.querySelector(`#btnp${i}poker`).disabled = true;
        document.querySelector(`#btnp${i}kissor`).disabled = true;
        document.querySelector(`#btnp${i}nagysor`).disabled = true;
        document.querySelector(`#btnp${i}nagypoker`).disabled = true;
        document.querySelector(`#btnp${i}szemet`).disabled = true;
    }
}

function JatekoslapAktivalo(i: number): void {

    let jatekos: boolean[] = JatekosHatarozo(i);

    document.querySelector(`#jatekos${i}`)?.classList.remove("fw-normal");
    document.querySelector(`#jatekos${i}`)?.classList.add("fw-bold");
    document.querySelector(`#sump${i}`)?.classList.remove("fw-normal");
    document.querySelector(`#sump${i}`)?.classList.add("fw-bold");
    document.querySelector(`#btnp${i}haz1`).disabled = jatekos[0];
    document.querySelector(`#btnp${i}haz2`).disabled = jatekos[1];
    document.querySelector(`#btnp${i}haz3`).disabled = jatekos[2];
    document.querySelector(`#btnp${i}haz4`).disabled = jatekos[3];
    document.querySelector(`#btnp${i}haz5`).disabled = jatekos[4];
    document.querySelector(`#btnp${i}haz6`).disabled = jatekos[5];
    document.querySelector(`#btnp${i}par`).disabled = jatekos[6];
    document.querySelector(`#btnp${i}ketpar`).disabled = jatekos[7];
    document.querySelector(`#btnp${i}drill`).disabled = jatekos[8];
    document.querySelector(`#btnp${i}full`).disabled = jatekos[9];
    document.querySelector(`#btnp${i}poker`).disabled = jatekos[10];
    document.querySelector(`#btnp${i}kissor`).disabled = jatekos[11];
    document.querySelector(`#btnp${i}nagysor`).disabled = jatekos[12];
    document.querySelector(`#btnp${i}nagypoker`).disabled = jatekos[13];
    document.querySelector(`#btnp${i}szemet`).disabled = jatekos[14];

    var keszAHaz: boolean = KeszHazVizsgalo(jatekos);
    if (keszAHaz == false) {
        document.querySelector(`#btnp${i}par`).disabled = true;
        document.querySelector(`#btnp${i}ketpar`).disabled = true;
        document.querySelector(`#btnp${i}drill`).disabled = true;
        document.querySelector(`#btnp${i}full`).disabled = true;
        document.querySelector(`#btnp${i}poker`).disabled = true;
        document.querySelector(`#btnp${i}kissor`).disabled = true;
        document.querySelector(`#btnp${i}nagysor`).disabled = true;
        document.querySelector(`#btnp${i}nagypoker`).disabled = true;
        document.querySelector(`#btnp${i}szemet`).disabled = true;
    }
}

function KeszHazVizsgalo(jatekos: boolean[]): boolean {
    let hazKeszSum: number = 0
    for (let i: number = 0; i <= 5; i++) {
        if (jatekos[i] == true) { hazKeszSum++ }
    }
    if (hazKeszSum == 6) { return true }
    else { return false }
}

function JatekosLepteto(): void {
    if (playerActual == playerDB) { playerActual = 1 }
    else { playerActual++ }
    JatekoslapDeaktivalo();
    JatekoslapAktivalo(playerActual);
    KockadobasReset();
    KockaEltuntetes();
    dobasSum++;
    if (dobasSum == (playerDB * 15)) { kockaMegjegyzesDom?.innerHTML = `Véget ért a játék! Köszönöm!` }
}

// Gombvizsgálat függvények

function HazVizsgalatP1(jatekosIndex: number, melyikTripla: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    player1Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function HazVizsgalatP2(jatekosIndex: number, melyikTripla: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    player2Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function HazVizsgalatP3(jatekosIndex: number, melyikTripla: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    player3Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function HazVizsgalatP4(jatekosIndex: number, melyikTripla: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    player4Sum += (melyikTripla * dobasErtekDB[melyikTripla]);
    jatekos[melyikTripla - 1] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function ParVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player1Sum += (i * dobasErtekDB[i]); break
        }
    }
    jatekos[6] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function ParVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player2Sum += (i * dobasErtekDB[i]); break
        }
    }
    jatekos[6] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function ParVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player3Sum += (i * dobasErtekDB[i]); break
        }
    }
    jatekos[6] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function ParVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 2) {
            player4Sum += (i * dobasErtekDB[i]); break
        }
    }
    jatekos[6] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function KetParVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let parokSzama: number = 0;
    let pontErtek: number = 0;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i])
            parokSzama++
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) { player1Sum += pontErtek }
    jatekos[7] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function KetParVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let parokSzama: number = 0;
    let pontErtek: number = 0;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i])
            parokSzama++
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) { player2Sum += pontErtek }
    jatekos[7] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function KetParVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let parokSzama: number = 0;
    let pontErtek: number = 0;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i])
            parokSzama++
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) { player3Sum += pontErtek }
    jatekos[7] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function KetParVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let parokSzama: number = 0;
    let pontErtek: number = 0;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 2 || dobasErtekDB[i] == 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama++;
        }
        if (dobasErtekDB[i] > 3) {
            pontErtek += (i * dobasErtekDB[i]);
            parokSzama += 2;
        }
    }
    if (parokSzama > 1) { player4Sum += pontErtek }
    jatekos[7] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function DrillVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player1Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function DrillVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player2Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function DrillVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player3Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function DrillVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 3) {
            player4Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[8] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function FullVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let fullSum: number = 0;
    let full3: boolean = false;
    let full2: boolean = false;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) { player1Sum += fullSum }
    jatekos[9] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function FullVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let fullSum: number = 0;
    let full3: boolean = false;
    let full2: boolean = false;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) { player2Sum += fullSum }
    jatekos[9] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function FullVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let fullSum: number = 0;
    let full3: boolean = false;
    let full2: boolean = false;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) { player3Sum += fullSum }
    jatekos[9] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function FullVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    let fullSum: number = 0;
    let full3: boolean = false;
    let full2: boolean = false;
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 3) {
            fullSum += (i * dobasErtekDB[i]);
            full3 = true;
        }
        else if (dobasErtekDB[i] == 2) {
            fullSum += (i * dobasErtekDB[i]);
            full2 = true;
        }
    }
    if (full3 && full2) { player4Sum += fullSum }
    jatekos[9] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function PokerVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player1Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function PokerVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player2Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function PokerVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player3Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function PokerVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] >= 4) {
            player4Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[10] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function KissorVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let egyes: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) { egyes = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (egyes && kettes && harmas && negyes && otos) { player1Sum += 15 }
    jatekos[11] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function KissorVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let egyes: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) { egyes = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (egyes && kettes && harmas && negyes && otos) { player2Sum += 15 }
    jatekos[11] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function KissorVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let egyes: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) { egyes = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (egyes && kettes && harmas && negyes && otos) { player3Sum += 15 }
    jatekos[11] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function KissorVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let egyes: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 1) { egyes = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (egyes && kettes && harmas && negyes && otos) { player4Sum += 15 }
    jatekos[11] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function NagysorVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let hatos: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) { hatos = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (hatos && kettes && harmas && negyes && otos) { player1Sum += 20 }
    jatekos[12] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function NagysorVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let hatos: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) { hatos = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (hatos && kettes && harmas && negyes && otos) { player2Sum += 20 }
    jatekos[12] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function NagysorVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let hatos: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) { hatos = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (hatos && kettes && harmas && negyes && otos) { player3Sum += 20 }
    jatekos[12] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function NagysorVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let hatos: boolean = false;
    let kettes: boolean = false;
    let harmas: boolean = false;
    let negyes: boolean = false;
    let otos: boolean = false;
    for (let i: number = 0; i < dobas.length; i++) {
        if (dobas[i] == 6) { hatos = true }
        if (dobas[i] == 2) { kettes = true }
        if (dobas[i] == 3) { harmas = true }
        if (dobas[i] == 4) { negyes = true }
        if (dobas[i] == 5) { otos = true }
    }
    if (hatos && kettes && harmas && negyes && otos) { player4Sum += 20 }
    jatekos[12] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function NagyPokerVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player1Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function NagyPokerVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player2Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function NagyPokerVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player3Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function NagyPokerVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    let dobasErtekDB: number[] = [0, 0, 0, 0, 0, 0, 0];
    for (let i: number = 0; i < dobas.length; i++) {
        dobasErtekDB[dobas[i]]++
    }
    for (let i: number = dobasErtekDB.length - 1; i > 0; i--) {
        if (dobasErtekDB[i] == 5) {
            player4Sum += (i * dobasErtekDB[i]);
        }
    }
    jatekos[13] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}

function SzemetVizsgalatP1(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    for (let i: number = 0; i < dobas.length; i++) {
        player1Sum += dobas[i];
    }
    jatekos[14] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player1Sum;
    JatekosLepteto();
}

function SzemetVizsgalatP2(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    for (let i: number = 0; i < dobas.length; i++) {
        player2Sum += dobas[i];
    }
    jatekos[14] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player2Sum;
    JatekosLepteto();
}

function SzemetVizsgalatP3(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    for (let i: number = 0; i < dobas.length; i++) {
        player3Sum += dobas[i];
    }
    jatekos[14] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player3Sum;
    JatekosLepteto();
}

function SzemetVizsgalatP4(jatekosIndex: number): void {
    let jatekos: boolean[] = JatekosHatarozo(jatekosIndex);
    for (let i: number = 0; i < dobas.length; i++) {
        player4Sum += dobas[i];
    }
    jatekos[14] = true;
    document.querySelector(`#sump${jatekosIndex}`)?.innerHTML = player4Sum;
    JatekosLepteto();
}



// Gombfigyelés

document.querySelector("#btnp1haz1")?.addEventListener("click", function () { HazVizsgalatP1(1, 1) });
document.querySelector("#btnp2haz1")?.addEventListener("click", function () { HazVizsgalatP2(2, 1) });
document.querySelector("#btnp3haz1")?.addEventListener("click", function () { HazVizsgalatP3(3, 1) });
document.querySelector("#btnp4haz1")?.addEventListener("click", function () { HazVizsgalatP4(4, 1) });
document.querySelector("#btnp1haz2")?.addEventListener("click", function () { HazVizsgalatP1(1, 2) });
document.querySelector("#btnp2haz2")?.addEventListener("click", function () { HazVizsgalatP2(2, 2) });
document.querySelector("#btnp3haz2")?.addEventListener("click", function () { HazVizsgalatP3(3, 2) });
document.querySelector("#btnp4haz2")?.addEventListener("click", function () { HazVizsgalatP4(4, 2) });
document.querySelector("#btnp1haz3")?.addEventListener("click", function () { HazVizsgalatP1(1, 3) });
document.querySelector("#btnp2haz3")?.addEventListener("click", function () { HazVizsgalatP2(2, 3) });
document.querySelector("#btnp3haz3")?.addEventListener("click", function () { HazVizsgalatP3(3, 3) });
document.querySelector("#btnp4haz3")?.addEventListener("click", function () { HazVizsgalatP4(4, 3) });
document.querySelector("#btnp1haz4")?.addEventListener("click", function () { HazVizsgalatP1(1, 4) });
document.querySelector("#btnp2haz4")?.addEventListener("click", function () { HazVizsgalatP2(2, 4) });
document.querySelector("#btnp3haz4")?.addEventListener("click", function () { HazVizsgalatP3(3, 4) });
document.querySelector("#btnp4haz4")?.addEventListener("click", function () { HazVizsgalatP4(4, 4) });
document.querySelector("#btnp1haz5")?.addEventListener("click", function () { HazVizsgalatP1(1, 5) });
document.querySelector("#btnp2haz5")?.addEventListener("click", function () { HazVizsgalatP2(2, 5) });
document.querySelector("#btnp3haz5")?.addEventListener("click", function () { HazVizsgalatP3(3, 5) });
document.querySelector("#btnp4haz5")?.addEventListener("click", function () { HazVizsgalatP4(4, 5) });
document.querySelector("#btnp1haz6")?.addEventListener("click", function () { HazVizsgalatP1(1, 6) });
document.querySelector("#btnp2haz6")?.addEventListener("click", function () { HazVizsgalatP2(2, 6) });
document.querySelector("#btnp3haz6")?.addEventListener("click", function () { HazVizsgalatP3(3, 6) });
document.querySelector("#btnp4haz6")?.addEventListener("click", function () { HazVizsgalatP4(4, 6) });
document.querySelector("#btnp1par")?.addEventListener("click", function () { ParVizsgalatP1(1) });
document.querySelector("#btnp2par")?.addEventListener("click", function () { ParVizsgalatP2(2) });
document.querySelector("#btnp3par")?.addEventListener("click", function () { ParVizsgalatP3(3) });
document.querySelector("#btnp4par")?.addEventListener("click", function () { ParVizsgalatP4(4) });
document.querySelector("#btnp1ketpar")?.addEventListener("click", function () { KetParVizsgalatP1(1) });
document.querySelector("#btnp2ketpar")?.addEventListener("click", function () { KetParVizsgalatP2(2) });
document.querySelector("#btnp3ketpar")?.addEventListener("click", function () { KetParVizsgalatP3(3) });
document.querySelector("#btnp4ketpar")?.addEventListener("click", function () { KetParVizsgalatP4(4) });
document.querySelector("#btnp1drill")?.addEventListener("click", function () { DrillVizsgalatP1(1) });
document.querySelector("#btnp2drill")?.addEventListener("click", function () { DrillVizsgalatP2(2) });
document.querySelector("#btnp3drill")?.addEventListener("click", function () { DrillVizsgalatP3(3) });
document.querySelector("#btnp4drill")?.addEventListener("click", function () { DrillVizsgalatP4(4) });
document.querySelector("#btnp1full")?.addEventListener("click", function () { FullVizsgalatP1(1) });
document.querySelector("#btnp2full")?.addEventListener("click", function () { FullVizsgalatP2(2) });
document.querySelector("#btnp3full")?.addEventListener("click", function () { FullVizsgalatP3(3) });
document.querySelector("#btnp4full")?.addEventListener("click", function () { FullVizsgalatP4(4) });
document.querySelector("#btnp1poker")?.addEventListener("click", function () { PokerVizsgalatP1(1) });
document.querySelector("#btnp2poker")?.addEventListener("click", function () { PokerVizsgalatP2(2) });
document.querySelector("#btnp3poker")?.addEventListener("click", function () { PokerVizsgalatP3(3) });
document.querySelector("#btnp4poker")?.addEventListener("click", function () { PokerVizsgalatP4(4) });
document.querySelector("#btnp1kissor")?.addEventListener("click", function () { KissorVizsgalatP1(1) });
document.querySelector("#btnp2kissor")?.addEventListener("click", function () { KissorVizsgalatP2(2) });
document.querySelector("#btnp3kissor")?.addEventListener("click", function () { KissorVizsgalatP3(3) });
document.querySelector("#btnp4kissor")?.addEventListener("click", function () { KissorVizsgalatP4(4) });
document.querySelector("#btnp1nagysor")?.addEventListener("click", function () { NagysorVizsgalatP1(1) });
document.querySelector("#btnp2nagysor")?.addEventListener("click", function () { NagysorVizsgalatP2(2) });
document.querySelector("#btnp3nagysor")?.addEventListener("click", function () { NagysorVizsgalatP3(3) });
document.querySelector("#btnp4nagysor")?.addEventListener("click", function () { NagysorVizsgalatP4(4) });
document.querySelector("#btnp1nagypoker")?.addEventListener("click", function () { NagyPokerVizsgalatP1(1) });
document.querySelector("#btnp2nagypoker")?.addEventListener("click", function () { NagyPokerVizsgalatP2(2) });
document.querySelector("#btnp3nagypoker")?.addEventListener("click", function () { NagyPokerVizsgalatP3(3) });
document.querySelector("#btnp4nagypoker")?.addEventListener("click", function () { NagyPokerVizsgalatP4(4) });
document.querySelector("#btnp1szemet")?.addEventListener("click", function () { SzemetVizsgalatP1(1) });
document.querySelector("#btnp2szemet")?.addEventListener("click", function () { SzemetVizsgalatP2(2) });
document.querySelector("#btnp3szemet")?.addEventListener("click", function () { SzemetVizsgalatP3(3) });
document.querySelector("#btnp4szemet")?.addEventListener("click", function () { SzemetVizsgalatP4(4) });