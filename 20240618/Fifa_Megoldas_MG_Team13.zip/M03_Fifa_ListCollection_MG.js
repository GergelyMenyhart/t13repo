const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/";

async function ListCollection() {
    try {
        const client = await MongoClient.connect(url);
        const collection = client.db("T13").collection("Fifa");

        var sortInfo = { pontszam: -1 };

        var listData = await collection.find({}, { projection: { _id: 0, csapat: 1, helyezes: 1 } }).sort({ pontszam: 1 }).toArray();

        console.log(listData);

        console.log("Feladat végrehajtva!");
        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

ListCollection();