const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/";

async function CreateFifaCollection() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13");

        await db.createCollection("Fifa");
        console.log("Feladat végrehajtva!")

        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

CreateFifaCollection();