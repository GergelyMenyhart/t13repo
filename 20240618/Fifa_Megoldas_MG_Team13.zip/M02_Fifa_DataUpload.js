const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/";

//Csapat;Helyezes;Valtozas;Pontszam
const fifa = [
    "Anglia;4;0;1662",
    "Argentína;10;0;1614",
    "Belgium;1;0;1752",
    "Brazília;3;-1;1719",
    "Chile;17;-3;1576",
    "Dánia;14;-1;1584",
    "Franciaország;2;1;1725",
    "Hollandia;13;3;1586",
    "Horvátország;8;-1;1625",
    "Kolumbia;9;-1;1622",
    "Mexikó;12;0;1603",
    "Németország;16;-1;1580",
    "Olaszország;15;1;1583",
    "Peru;19;0;1551",
    "Portugália;5;1;1643",
    "Spanyolország;7;2;1631",
    "Svájc;11;0;1604",
    "Svédország;18;0;1560",
    "Szenegál;20;0;1546",
    "Uruguay;6;-1;1639",
]

async function DataUpload() {
    try {
        const client = await MongoClient.connect(url);
        const collection = client.db("T13").collection("Fifa");

        for (i = 0; i < fifa.length; i++) {
            let separatedData = fifa[i].split(";");
            let uploadDataObject = {
                csapat: separatedData[0],
                helyezes: Number(separatedData[1]),
                valtozas: Number(separatedData[2]),
                pontszam: Number(separatedData[3])
            }
            await collection.insertOne(uploadDataObject)
        }
        console.log("Adatfeltöltés sikeres!");

        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

DataUpload();