const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/";

async function Best3() {
    try {
        const client = await MongoClient.connect(url);
        const collection = client.db("T13").collection("Fifa");

        var best3 = await collection.find().sort({ helyezes: 1 }).limit(3).toArray();
        console.log(best3);

        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

Best3();