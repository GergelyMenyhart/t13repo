const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/";

async function StayingTeams() {
    try {
        const client = await MongoClient.connect(url);
        const collection = client.db("T13").collection("Fifa");

        var findData = await collection.find({ valtozas: 0 }, { projection: { _id: 0, csapat: 1 } }).toArray();
        console.log(findData);

        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

StayingTeams();