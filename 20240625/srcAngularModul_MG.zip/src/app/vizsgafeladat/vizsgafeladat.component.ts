import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrl: './vizsgafeladat.component.css'
})
export class VizsgafeladatComponent {
  suly!: number;
  magassag!: number;
  tti!: number;
  eredmenyek: string[] = [];
  EredmenyMentes(): void {
    this.tti = (this.suly / (this.magassag * this.magassag));
    this.eredmenyek.push(`A(z) ${this.suly} kg testsulyú és ${this.magassag} méter magasságú ember testömeg indexe: ${this.tti}`)
  }

}
