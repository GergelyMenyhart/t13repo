const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

async function FindTornaUszas() {
    try {
        const client = await MongoClient.connect(url);
        const collection = client.db("T13").collection("Helsinki");

        let findItem = { $or: [{ sportag: "torna" }, { sportag: "uszas" }] };
        let projectionData = { _id: 0, sportag: 1, versenyszam: 1 };

        let writeOut = await collection.find(findItem, { projection: projectionData }).toArray();

        console.log(writeOut);

        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

FindTornaUszas();