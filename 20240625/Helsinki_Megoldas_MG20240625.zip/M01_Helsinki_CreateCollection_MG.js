const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

async function CreateCollection() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13");

        await db.createCollection("Helsinki");

        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

CreateCollection();