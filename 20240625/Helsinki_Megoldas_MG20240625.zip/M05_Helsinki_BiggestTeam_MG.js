const MongoClient = require("mongodb").MongoClient;
const url = "mongodb+srv://gergelymenyhart:Naslund@cluster0.cq09h2b.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

async function FindBiggestTeam() {
    try {
        const client = await MongoClient.connect(url);
        const collection = client.db("T13").collection("Helsinki");

        let findItem = {};
        let projectionData = {};

        let writeOut = await collection.find(findItem, { projection: projectionData }).sort({ csapatmeret: -1 }).limit(1).toArray();

        console.log(writeOut);

        client.close();
    }
    catch (err) {
        console.error("Hiba történt!", err)
    }
}

FindBiggestTeam();