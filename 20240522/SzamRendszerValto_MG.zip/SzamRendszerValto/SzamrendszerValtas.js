var _a;
function KettesTizesSzamrendszerValtas(kettes) {
    var tizes = 0;
    kettes = kettes.toString();
    for (var i = kettes.length - 1; i >= 0; i--) {
        tizes += Math.pow(2, (kettes.length - 1 - i)) * Number(kettes[i]);
    }
    return tizes;
}
console.log(KettesTizesSzamrendszerValtas(101101101));
/*
function TizesKettesSzamrendszerValtas(tizes: number): number {
    var kettes: number[] = [];
    var aktualisSzam: number = tizes;
    for (var i: number = Math.floor(Math.log2(tizes)); i >= 0; i--) {
        if (aktualisSzam >= (2 ** i)) {
            kettes.push(1);
            aktualisSzam -= (2 ** i);
        }
        else { kettes.push(0) }
    }
    return Number(kettes.join(""))
}

console.log(TizesKettesSzamrendszerValtas(365));*/
function BarmiTizesSzamrendszerValtas(megadottSzam, szamrendszer) {
    var eredmeny = 0;
    megadottSzam = megadottSzam.toString();
    if (szamrendszer == 16) {
        var megadottSzamTomb = megadottSzam.split("");
        var megadottSzamTomb10 = [];
        for (var i = 0; i < megadottSzamTomb.length; i++) {
            if (megadottSzamTomb[i] == "a" ||
                megadottSzamTomb[i] == "b" ||
                megadottSzamTomb[i] == "c" ||
                megadottSzamTomb[i] == "d" ||
                megadottSzamTomb[i] == "e" ||
                megadottSzamTomb[i] == "f") {
                megadottSzamTomb10.push(Number(HexaFordito(megadottSzamTomb[i])));
            }
            else {
                megadottSzamTomb10.push(Number(HexaFordito(Number(megadottSzamTomb[i]))));
            }
        }
        for (var i = 0; i < megadottSzamTomb10.length; i++) {
            eredmeny += Math.pow(szamrendszer, (megadottSzamTomb10.length - 1 - i)) * Number(megadottSzamTomb10[i]);
        }
        return eredmeny;
    }
    for (var i = megadottSzam.length - 1; i >= 0; i--) {
        eredmeny += Math.pow(szamrendszer, (megadottSzam.length - 1 - i)) * Number(megadottSzam[i]);
    }
    return eredmeny;
}
console.log(BarmiTizesSzamrendszerValtas("1fb3", 16));
function SzamrendszerValtas(megadottSzam, celSzamrendszer) {
    var eredmeny = [];
    var aktualisSzam = megadottSzam;
    var legmagasabbHatvany = 0;
    while (aktualisSzam >= Math.pow(celSzamrendszer, legmagasabbHatvany)) {
        legmagasabbHatvany++;
    }
    for (var i = legmagasabbHatvany - 1; i >= 0; i--) {
        if (aktualisSzam >= (Math.pow(celSzamrendszer, i))) {
            eredmeny.push(Math.floor(aktualisSzam / Math.pow(celSzamrendszer, i)));
            aktualisSzam -= (Math.floor(aktualisSzam / Math.pow(celSzamrendszer, i)) * Math.pow(celSzamrendszer, i));
        }
        else if (aktualisSzam != 0) {
            eredmeny.push(0);
        }
        else if (aktualisSzam == 0 && i >= 0) {
            eredmeny.push(0);
        }
    }
    if (celSzamrendszer == 16) {
        for (var i = 0; i < eredmeny.length; i++) {
            eredmeny[i] = HexaFordito(eredmeny[i]);
        }
        return eredmeny.join("");
    }
    return Number(eredmeny.join(""));
}
function SzamrendszerValtasKiiratas() {
    for (var i = 2; i < 17; i++) {
        console.log(SzamrendszerValtas(1500, i));
    }
}
SzamrendszerValtasKiiratas();
function HexaFordito(hexaSzam) {
    if (hexaSzam == 10) {
        return "a";
    }
    else if (hexaSzam == 11) {
        return "b";
    }
    else if (hexaSzam == 12) {
        return "c";
    }
    else if (hexaSzam == 13) {
        return "d";
    }
    else if (hexaSzam == 14) {
        return "e";
    }
    else if (hexaSzam == 15) {
        return "f";
    }
    else if (hexaSzam == "a") {
        return 10;
    }
    else if (hexaSzam == "b") {
        return 11;
    }
    else if (hexaSzam == "c") {
        return 12;
    }
    else if (hexaSzam == "d") {
        return 13;
    }
    else if (hexaSzam == "e") {
        return 14;
    }
    else if (hexaSzam == "f") {
        return 15;
    }
    else {
        return hexaSzam;
    }
}
(_a = document.querySelector("#szamitas")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", Szamitas);
function Szamitas() {
    var _a, _b, _c;
    var szamrendszerBal = document.querySelector("#rendszervalaszto1").value;
    var szamrendszerKozep = document.querySelector("#rendszervalaszto2").value;
    var szamrendszerJobb = document.querySelector("#rendszervalaszto3").value;
    var szamBeolvasott = (_a = document.querySelector("#inputszam")) === null || _a === void 0 ? void 0 : _a.value;
    var szam = BarmiTizesSzamrendszerValtas(szamBeolvasott, szamrendszerKozep);
    var szamBal = SzamrendszerValtas(szam, szamrendszerBal);
    var szamJobb = SzamrendszerValtas(szam, szamrendszerJobb);
    (_b = document.querySelector("#szamitasbal")) === null || _b === void 0 ? void 0 : _b.innerHTML = szamBal;
    (_c = document.querySelector("#szamitasjobb")) === null || _c === void 0 ? void 0 : _c.innerHTML = szamJobb;
}
