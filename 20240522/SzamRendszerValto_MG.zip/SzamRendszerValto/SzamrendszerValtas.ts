function KettesTizesSzamrendszerValtas(kettes: string | number): number {
    var tizes: number = 0;
    kettes = kettes.toString();
    for (let i: number = kettes.length - 1; i >= 0; i--) {
        tizes += 2 ** (kettes.length - 1 - i) * Number(kettes[i]);
    }
    return tizes
}

console.log(KettesTizesSzamrendszerValtas(101101101));
/*
function TizesKettesSzamrendszerValtas(tizes: number): number {
    var kettes: number[] = [];
    var aktualisSzam: number = tizes;
    for (var i: number = Math.floor(Math.log2(tizes)); i >= 0; i--) {
        if (aktualisSzam >= (2 ** i)) {
            kettes.push(1);
            aktualisSzam -= (2 ** i);
        }
        else { kettes.push(0) }
    }
    return Number(kettes.join(""))
}

console.log(TizesKettesSzamrendszerValtas(365));*/

function BarmiTizesSzamrendszerValtas(megadottSzam: string | number, szamrendszer: number): number {
    var eredmeny: number = 0;
    megadottSzam = megadottSzam.toString();
    if (szamrendszer == 16) {
        var megadottSzamTomb: string[] = megadottSzam.split("");
        var megadottSzamTomb10: number[] = [];
        for (let i: number = 0; i < megadottSzamTomb.length; i++) {
            if (megadottSzamTomb[i] == "a" ||
                megadottSzamTomb[i] == "b" ||
                megadottSzamTomb[i] == "c" ||
                megadottSzamTomb[i] == "d" ||
                megadottSzamTomb[i] == "e" ||
                megadottSzamTomb[i] == "f") { megadottSzamTomb10.push(Number(HexaFordito(megadottSzamTomb[i]))) }
            else { megadottSzamTomb10.push(Number(HexaFordito(Number(megadottSzamTomb[i])))) }
        }
        for (let i: number = 0; i < megadottSzamTomb10.length; i++) {
            eredmeny += szamrendszer ** (megadottSzamTomb10.length - 1 - i) * Number(megadottSzamTomb10[i])
        }
        return eredmeny
    }
    for (let i: number = megadottSzam.length - 1; i >= 0; i--) {
        eredmeny += szamrendszer ** (megadottSzam.length - 1 - i) * Number(megadottSzam[i]);
    }
    return eredmeny
}

console.log(BarmiTizesSzamrendszerValtas("1fb3", 16));


function SzamrendszerValtas(megadottSzam: number, celSzamrendszer: number): number | string {
    var eredmeny: any[] = [];
    var aktualisSzam: number = megadottSzam;
    var legmagasabbHatvany: number = 0;
    while (aktualisSzam >= celSzamrendszer ** legmagasabbHatvany) {
        legmagasabbHatvany++
    }
    for (var i: number = legmagasabbHatvany - 1; i >= 0; i--) {
        if (aktualisSzam >= (celSzamrendszer ** i)) {
            eredmeny.push(Math.floor(aktualisSzam / celSzamrendszer ** i));
            aktualisSzam -= (Math.floor(aktualisSzam / celSzamrendszer ** i) * celSzamrendszer ** i);
        }
        else if (aktualisSzam != 0) { eredmeny.push(0) }
        else if (aktualisSzam == 0 && i >= 0) { eredmeny.push(0) }
    }
    if (celSzamrendszer == 16) {
        for (var i: number = 0; i < eredmeny.length; i++) {
            eredmeny[i] = HexaFordito(eredmeny[i])
        }
        return eredmeny.join("")
    }
    return Number(eredmeny.join(""))
}

function SzamrendszerValtasKiiratas(): void {
    for (let i: number = 2; i < 17; i++) {
        console.log(SzamrendszerValtas(1500, i))
    }
}

SzamrendszerValtasKiiratas();

function HexaFordito(hexaSzam: any): number | string {
    if (hexaSzam == 10) { return "a" }
    else if (hexaSzam == 11) { return "b" }
    else if (hexaSzam == 12) { return "c" }
    else if (hexaSzam == 13) { return "d" }
    else if (hexaSzam == 14) { return "e" }
    else if (hexaSzam == 15) { return "f" }
    else if (hexaSzam == "a") { return 10 }
    else if (hexaSzam == "b") { return 11 }
    else if (hexaSzam == "c") { return 12 }
    else if (hexaSzam == "d") { return 13 }
    else if (hexaSzam == "e") { return 14 }
    else if (hexaSzam == "f") { return 15 }
    else { return hexaSzam }
}

document.querySelector("#szamitas")?.addEventListener("click", Szamitas);

function Szamitas(): void {
    var szamrendszerBal: number = document.querySelector("#rendszervalaszto1").value;
    var szamrendszerKozep: number = document.querySelector("#rendszervalaszto2").value;
    var szamrendszerJobb: number = document.querySelector("#rendszervalaszto3").value;

    var szamBeolvasott: any = document.querySelector("#inputszam")?.value;
    var szam: any = BarmiTizesSzamrendszerValtas(szamBeolvasott, szamrendszerKozep);

    var szamBal: any = SzamrendszerValtas(szam, szamrendszerBal);
    var szamJobb: any = SzamrendszerValtas(szam, szamrendszerJobb);

    document.querySelector("#szamitasbal")?.innerHTML = szamBal;
    document.querySelector("#szamitasjobb")?.innerHTML = szamJobb;
}