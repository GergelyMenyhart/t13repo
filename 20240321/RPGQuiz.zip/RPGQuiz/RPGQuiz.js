let osszpontszam = 0;

function Feladat1() {
    let feladat = document.querySelector("#feladat1");
    let valaszto = document.querySelector("#valaszto1");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz1");

    if (feladat.value.toLowerCase().includes("skyrim")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz1").addEventListener("click", Feladat1);


function Feladat2() {
    let feladat = document.querySelector("#feladat2");
    let valaszto = document.querySelector("#valaszto2");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz2");

    if (feladat.value.toLowerCase().includes("witcher")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz2").addEventListener("click", Feladat2);


function Feladat3() {
    let feladat = document.querySelector("#feladat3");
    let valaszto = document.querySelector("#valaszto3");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz3");

    if (feladat.value.toLowerCase().includes("mass effect")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz3").addEventListener("click", Feladat3);


function Feladat4() {
    let feladat = document.querySelector("#feladat4");
    let valaszto = document.querySelector("#valaszto4");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz4");

    if (feladat.value.toLowerCase().includes("divinity")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz4").addEventListener("click", Feladat4);


function Feladat5() {
    let feladat = document.querySelector("#feladat5");
    let valaszto = document.querySelector("#valaszto5");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz5");

    if (feladat.value.toLowerCase().includes("fallout")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz5").addEventListener("click", Feladat5);


function Feladat6() {
    let feladat = document.querySelector("#feladat6");
    let valaszto = document.querySelector("#valaszto6");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz6");

    if (feladat.value.toLowerCase().includes("dragon age")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz6").addEventListener("click", Feladat6);


function Feladat7() {
    let feladat = document.querySelector("#feladat7");
    let valaszto = document.querySelector("#valaszto7");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz7");

    if (feladat.value.toLowerCase().includes("baldur")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz7").addEventListener("click", Feladat7);


function Feladat8() {
    let feladat = document.querySelector("#feladat8");
    let valaszto = document.querySelector("#valaszto8");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz8");

    if (feladat.value.toLowerCase().includes("beholder")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz8").addEventListener("click", Feladat8);


function Feladat9() {
    let feladat = document.querySelector("#feladat9");
    let valaszto = document.querySelector("#valaszto9");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz9");

    if (feladat.value.toLowerCase().includes("wizardry")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz9").addEventListener("click", Feladat9);


function Feladat10() {
    let feladat = document.querySelector("#feladat10");
    let valaszto = document.querySelector("#valaszto10");
    let valasztoszam = Number(valaszto.value)
    let valasz = document.querySelector("#valasz10");

    if (feladat.value.toLowerCase().includes("ultima")) { osszpontszam += 2 }
    else { osszpontszam += valasztoszam }

    feladat.setAttribute("disabled", true);
    valaszto.setAttribute("disabled", true);
    valasz.setAttribute("disabled", true);

}
document.querySelector("#valasz10").addEventListener("click", Feladat10);


function EredmenyKiirato() {
    let szoveg = document.querySelector("#eredmeny");
    console.log(osszpontszam);
    if (osszpontszam <= 5) { szoveg.innerHTML = `Hát, nem vagy egy nagy játékos...sebaj! Pontszámod: 20/${osszpontszam}` }
    if (osszpontszam <= 15 && osszpontszam > 5) { szoveg.innerHTML = `Nem rossz, ezekszerint néha leülsz játszani... Pontszámod: 20/${osszpontszam}` }
    if (osszpontszam > 15) { szoveg.innerHTML = `Gratulálok! Profi vagy! Pontszámod: 20/${osszpontszam}` }
}
document.querySelector("#valasz10").addEventListener("click", EredmenyKiirato);

