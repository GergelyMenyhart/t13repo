aktivalo.addEventListener("click", AktivaloMind)

function AktivaloMind() {
    let aktivalandoTomb = document.querySelectorAll(".allapot");
    for (i = 0; i < aktivalandoTomb.length; i++) {
        aktivalandoTomb[i].checked = true
    }
}

deaktivalo.addEventListener("click", DeaktivaloMind)

function DeaktivaloMind() {
    let deaktivaloTomb = document.querySelectorAll(".allapot");
    for (i = 0; i < deaktivaloTomb.length; i++) {
        deaktivaloTomb[i].checked = false
    }
}

document.querySelector("#pipavagynem").addEventListener("click", PipaVagyNem)

function PipaVagyNem() {
    let pipavagynemTomb = document.querySelectorAll(".allapot");
    let pipa = false;
    for (i = 0; i < pipavagynemTomb.length; i++) {
        if (pipavagynemTomb[i].checked == true) {
            pipa = true
        }
    }
    if (pipa == true) {
        for (i = 0; pipavagynemTomb.length; i++) {
            pipavagynemTomb[i].checked = false
        }
    }
    else {
        for (i = 0; pipavagynemTomb.length; i++) {
            pipavagynemTomb[i].checked = true
        }
    }
}

csikozasbe.addEventListener("click", CsikozásBe)

function CsikozásBe() {
    let table = document.querySelector("table");
    table.classList.add("table-striped")
}

csikozaski.addEventListener("click", CsikozásKi)

function CsikozásKi() {
    document.querySelector("table").classList.remove("table-striped");
}

csikozasvagynem.addEventListener("click", CsikozasVagyNem)

function CsikozasVagyNem() {
    let table = document.querySelector("table")
    let allapot = table.classList.contains("table-striped")
    if (allapot == true) {
        table.classList.remove("table-striped")
    }
    else { table.classList.add("table-striped") }
}

darkmode.addEventListener("click", DarkMode)

function DarkMode() {
    let table = document.querySelector("table");
    table.classList.remove("table-ligth")
    table.classList.add("table-dark")
}

ligthmode.addEventListener("click", LigthMode)

function LigthMode() {
    let table = document.querySelector("table");
    table.classList.remove("table-dark")
    table.classList.add("table-ligth")
}


darkorligth.addEventListener("click", DarkOrLigth)

function DarkOrLigth() {
    let table = document.querySelector("table");
    if (table.classList.contains("table-dark") == true) {
        table.classList.remove("table-dark");
        table.classList.add("table-ligth");
    }
    else {
        table.classList.remove("table-ligth");
        table.classList.add("table-dark");
    }
}

tesztsor.addEventListener("click", TesztSorBeszuras)

function TesztSorBeszuras() {
    let table = document.querySelector("table");
    let sor = table.insertRow();
    let vezNevCella = sor.insertCell();
    let kerNevCella = sor.insertCell();
    let emailCella = sor.insertCell();
    let telefonCella = sor.insertCell();
    let beosztasCella = sor.insertCell();
    let activeCella = sor.insertCell();
    vezNevCella.innerHTML = "teszt";
    kerNevCella.innerHTML = "teszt";
    emailCella.innerHTML = "teszt";
    telefonCella.innerHTML = "teszt";
    beosztasCella.innerHTML = "teszt";
    activeCella.innerHTML = `<input type="checkbox" class="allapot">`
}

felhasznaloSubmit.addEventListener("click", FelhasznaloSubmit)

function FelhasznaloSubmit() {
    let table = document.querySelector("table");
    let sor = table.insertRow();
    let vezNevCella = sor.insertCell();
    let kerNevCella = sor.insertCell();
    let emailCella = sor.insertCell();
    let telefonCella = sor.insertCell();
    let beosztasCella = sor.insertCell();
    let activeCella = sor.insertCell();
    vezNevCella.innerHTML = document.querySelector("#vezeteknev").value;
    kerNevCella.innerHTML = document.querySelector("#keresztnev").value;
    emailCella.innerHTML = document.querySelector("#email").value;
    telefonCella.innerHTML = document.querySelector("#telefon").value;
    beosztasCella.innerHTML = document.querySelector("#beosztas").value;
    activeCella.innerHTML = `<input type="checkbox" class="allapot">`
}

