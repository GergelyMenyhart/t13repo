var csapatAdat = [
    "Anglia;4;0;1662",
    "Argentína;10;0;1614",
    "Belgium;1;0;1752",
    "Brazília;3;-1;1719",
    "Chile;17;-3;1576",
    "Dánia;14;-1;1584",
    "Franciaország;2;1;1725",
    "Hollandia;13;3;1586",
    "Horvátország;8;-1;1625",
    "Kolumbia;9;-1;1622",
    "Mexikó;12;0;1603",
    "Németország;16;-1;1580",
    "Olaszország;15;1;1583",
    "Peru;19;0;1551",
    "Portugália;5;1;1643",
    "Spanyolország;7;2;1631",
    "Svájc;11;0;1604",
    "Svédország;18;0;1560",
    "Szenegál;20;0;1546",
    "Uruguay;6;-1;1639"
];
function AdatAtalakitas(vizsgaltTomb) {
    var teamDataBase = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var splitData = vizsgaltTomb[i].split(";");
        var reAssembledData = {
            csapatNeve: String(splitData[0]),
            helyezes: Number(splitData[1]),
            valtozas: Number(splitData[2]),
            pont: Number(splitData[3])
        };
        teamDataBase.push(reAssembledData);
    }
    return teamDataBase;
}
var teamDataBase = AdatAtalakitas(csapatAdat);
console.log(teamDataBase);
// Hány csapat van a ranglistán?
function CsapatokSzama(vizsgaltTomb) {
    return vizsgaltTomb.length;
}
console.log("".concat(CsapatokSzama(teamDataBase), " csapat van a list\u00E1n"));
// Csapatok átlagpontszáma
function AtlagPontSzam(vizsgaltTomb) {
    var sum = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        sum += vizsgaltTomb[i].pont;
    }
    return Number((sum / vizsgaltTomb.length).toFixed(2));
}
console.log("A csapatok \u00E1tlagpontsz\u00E1ma: ".concat(AtlagPontSzam(teamDataBase), " pont"));
// Átlagpontszám fölötti csapatok
function AtlagFelettiCsapatok(vizsgaltTomb) {
    var atlag = AtlagPontSzam(teamDataBase);
    var atlagFelettiCsapatok = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].pont > atlag) {
            atlagFelettiCsapatok.push(vizsgaltTomb[i].csapatNeve);
        }
    }
    return atlagFelettiCsapatok.sort();
}
console.log("Az \u00E1tlagpontsz\u00E1m feletti csapatok: ".concat(AtlagFelettiCsapatok(teamDataBase)));
// Írja ki a legtöbbet javító csapat adatait: Helyezés, CsapatNeve, Pontszáma
function LegtobbetJavito(vizsgaltTomb) {
    var legtobbetJavitoIndex = 0;
    //let legtobbetJavitoTomb: number[] = [];
    //let eredmeny: [number, string, number] = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].valtozas > vizsgaltTomb[legtobbetJavitoIndex].valtozas) {
            legtobbetJavitoIndex = i;
            //legtobbetJavitoTomb = [];
            //legtobbetJavitoTomb.push(i);
        }
        /*else if (vizsgaltTomb[i].valtozas == vizsgaltTomb[legtobbetJavitoIndex].valtozas) {
            legtobbetJavitoTomb.push(i); console.log(legtobbetJavitoTomb)
        }*/
    }
    /*for (let i: number = 0; i < legtobbetJavitoTomb.length; i++) {
        eredmeny.push(vizsgaltTomb[i].helyezes, vizsgaltTomb[i].csapatNeve, vizsgaltTomb[i].pont)
    }*/
    return [vizsgaltTomb[legtobbetJavitoIndex].helyezes, vizsgaltTomb[legtobbetJavitoIndex].csapatNeve, vizsgaltTomb[legtobbetJavitoIndex].pont];
}
console.log("A legt\u00F6bbet jav\u00EDt\u00F3 csapat(ok): ".concat(LegtobbetJavito(teamDataBase)));
// Határozza meg a adatok közöt megtalálható-e Magyarország csapata!
function MagyarorszagVanNincs(vizsgaltTomb) {
    var vane = false;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csapatNeve == "Magyarország") {
            vane = true;
        }
    }
    return vane;
}
console.log("Magyarorsz\u00E1g szerepel a list\u00E1ban? ".concat(MagyarorszagVanNincs(teamDataBase)));
// Készítsen  sta�sz�kát  a  helyezések  változása  (Valtozas)  alapján  csoportosítva  a  csapatok számáról  a  minta  szerint! 
function ValtozasVariaciok(vizsgaltTomb) {
    var valtozasVariaciokIndex = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var iter = false;
        for (var j = 0; j < valtozasVariaciokIndex.length; j++) {
            if (vizsgaltTomb[i].valtozas == valtozasVariaciokIndex[j]) {
                iter = true;
            }
        }
        if (!iter) {
            valtozasVariaciokIndex.push(vizsgaltTomb[i].valtozas);
        }
    }
    return valtozasVariaciokIndex.sort(function (a, b) { return a - b; });
}
console.log(ValtozasVariaciok(teamDataBase));
function ValtozasLista(vizsgaltTomb) {
    var valtozasVariaciok = ValtozasVariaciok(teamDataBase);
    var valtozasLista = [];
    for (var i = 0; i < valtozasVariaciok.length; i++) {
        var orszagTomb = [];
        for (var j = 0; j < vizsgaltTomb.length; j++) {
            if (valtozasVariaciok[i] == vizsgaltTomb[j].valtozas) {
                orszagTomb.push(vizsgaltTomb[j].csapatNeve);
            }
        }
        valtozasLista.push(valtozasVariaciok[i], orszagTomb);
    }
    return valtozasLista;
}
console.log(ValtozasLista(teamDataBase));
