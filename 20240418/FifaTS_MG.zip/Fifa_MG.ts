const csapatAdat = [
    "Anglia;4;0;1662",
    "Argentína;10;0;1614",
    "Belgium;1;0;1752",
    "Brazília;3;-1;1719",
    "Chile;17;-3;1576",
    "Dánia;14;-1;1584",
    "Franciaország;2;1;1725",
    "Hollandia;13;3;1586",
    "Horvátország;8;-1;1625",
    "Kolumbia;9;-1;1622",
    "Mexikó;12;0;1603",
    "Németország;16;-1;1580",
    "Olaszország;15;1;1583",
    "Peru;19;0;1551",
    "Portugália;5;1;1643",
    "Spanyolország;7;2;1631",
    "Svájc;11;0;1604",
    "Svédország;18;0;1560",
    "Szenegál;20;0;1546",
    "Uruguay;6;-1;1639"
];

// Alapadat Átalakítás

interface FifaAdat {
    csapatNeve: string;
    helyezes: number;
    valtozas: number;
    pont: number;
}

function AdatAtalakitas(vizsgaltTomb: string[]): FifaAdat[] {
    let teamDataBase: FifaAdat[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let splitData = vizsgaltTomb[i].split(";");
        let reAssembledData: FifaAdat = {
            csapatNeve: String(splitData[0]),
            helyezes: Number(splitData[1]),
            valtozas: Number(splitData[2]),
            pont: Number(splitData[3])
        }
        teamDataBase.push(reAssembledData)
    }
    return teamDataBase
}

let teamDataBase: FifaAdat[] = AdatAtalakitas(csapatAdat);

console.log(teamDataBase);

// Hány csapat van a ranglistán?

function CsapatokSzama(vizsgaltTomb: FifaAdat[]): number {
    return vizsgaltTomb.length
}

console.log(`${CsapatokSzama(teamDataBase)} csapat van a listán`)

// Csapatok átlagpontszáma

function AtlagPontSzam(vizsgaltTomb: FifaAdat[]): number {
    let sum: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        sum += vizsgaltTomb[i].pont;
    }
    return Number((sum / vizsgaltTomb.length).toFixed(2))
}

console.log(`A csapatok átlagpontszáma: ${AtlagPontSzam(teamDataBase)} pont`);

// Átlagpontszám fölötti csapatok

function AtlagFelettiCsapatok(vizsgaltTomb: FifaAdat[]): string[] {
    let atlag: number = AtlagPontSzam(teamDataBase);
    let atlagFelettiCsapatok: string[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].pont > atlag) { atlagFelettiCsapatok.push(vizsgaltTomb[i].csapatNeve) }
    }
    return atlagFelettiCsapatok.sort()
}

console.log(`Az átlagpontszám feletti csapatok: ${AtlagFelettiCsapatok(teamDataBase)}`);

// Írja ki a legtöbbet javító csapat adatait: Helyezés, CsapatNeve, Pontszáma

function LegtobbetJavito(vizsgaltTomb: FifaAdat[]): [number, string, number] {
    let legtobbetJavitoIndex: number = 0;
    //let legtobbetJavitoTomb: number[] = [];
    //let eredmeny: [number, string, number] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].valtozas > vizsgaltTomb[legtobbetJavitoIndex].valtozas) {
            legtobbetJavitoIndex = i;
            //legtobbetJavitoTomb = [];
            //legtobbetJavitoTomb.push(i);
        }
        /*else if (vizsgaltTomb[i].valtozas == vizsgaltTomb[legtobbetJavitoIndex].valtozas) {
            legtobbetJavitoTomb.push(i); console.log(legtobbetJavitoTomb)
        }*/

    }
    /*for (let i: number = 0; i < legtobbetJavitoTomb.length; i++) {
        eredmeny.push(vizsgaltTomb[i].helyezes, vizsgaltTomb[i].csapatNeve, vizsgaltTomb[i].pont)
    }*/
    return [vizsgaltTomb[legtobbetJavitoIndex].helyezes, vizsgaltTomb[legtobbetJavitoIndex].csapatNeve, vizsgaltTomb[legtobbetJavitoIndex].pont]
}

console.log(`A legtöbbet javító csapat(ok): ${LegtobbetJavito(teamDataBase)}`);

// Határozza meg a adatok közöt megtalálható-e Magyarország csapata!

function MagyarorszagVanNincs(vizsgaltTomb: FifaAdat[]): boolean {
    let vane: boolean = false;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].csapatNeve == "Magyarország") { vane = true }
    }
    return vane
}

console.log(`Magyarország szerepel a listában? ${MagyarorszagVanNincs(teamDataBase)}`);

// Készítsen  sta�sz�kát  a  helyezések  változása  (Valtozas)  alapján  csoportosítva  a  csapatok számáról  a  minta  szerint! 

function ValtozasVariaciok(vizsgaltTomb: FifaAdat[]): number[] {
    let valtozasVariaciokIndex: number[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let iter: boolean = false;
        for (let j: number = 0; j < valtozasVariaciokIndex.length; j++) {
            if (vizsgaltTomb[i].valtozas == valtozasVariaciokIndex[j]) { iter = true }
        }
        if (!iter) { valtozasVariaciokIndex.push(vizsgaltTomb[i].valtozas) }
    }
    return valtozasVariaciokIndex.sort(function (a, b) { return a - b })
}

console.log(ValtozasVariaciok(teamDataBase));

function ValtozasLista(vizsgaltTomb: FifaAdat[]): [number, string[]] {
    let valtozasVariaciok: number[] = ValtozasVariaciok(teamDataBase);
    let valtozasLista: [number, string[]] = [];
    for (let i: number = 0; i < valtozasVariaciok.length; i++) {
        let orszagTomb: string[] = [];
        for (let j: number = 0; j < vizsgaltTomb.length; j++) {
            if (valtozasVariaciok[i] == vizsgaltTomb[j].valtozas) {
                orszagTomb.push(vizsgaltTomb[j].csapatNeve)
            }
        }
        valtozasLista.push(valtozasVariaciok[i], orszagTomb)
    }
    return valtozasLista
}

console.log(ValtozasLista(teamDataBase));
